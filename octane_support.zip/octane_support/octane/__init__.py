# This file makes the octane folder a Python package
# It can be empty, but we'll add version info for good practice

bl_info = {
    "version": (1, 0, 0)
}

__all__ = ['octane_support', 'octane_world']