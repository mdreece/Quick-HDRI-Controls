import bpy
import os
from math import radians
def is_octane_available():
    """Check if Octane render engine is available"""
    return hasattr(bpy.types, "OctaneRender")
def is_octane_active():
    """Check if Octane is the active render engine"""
    return bpy.context.scene.render.engine == 'octane'
def setup_octane_world():
    """Create or get the Octane world with proper node setup"""
    # Create or get world named 'octane_world'
    world = bpy.data.worlds.new(name='octane_world') if 'octane_world' not in bpy.data.worlds else bpy.data.worlds['octane_world']
    world.use_nodes = True
    
    nodes = world.node_tree.nodes
    links = world.node_tree.links
    
    # Clear existing nodes
    nodes.clear()
    
    # Create nodes
    node_OctaneWorld = nodes.new(type='OctaneEditorWorldOutputNode')
    node_HDRIControls = nodes.new(type='OctaneTextureEnvironment')
    node_HDRI = nodes.new(type='OctaneRGBImage')
    node_HDRIprojection = nodes.new(type='OctaneSpherical')
    node_HDRItransform = nodes.new(type='Octane3DTransformation')
    node_Visibility = nodes.new(type='OctaneTextureEnvironment')
    node_RGBColor = nodes.new(type='OctaneRGBColor')
    
    # Set node locations
    node_OctaneWorld.location = (260, 334)
    node_HDRIControls.location = (38, 334)
    node_HDRI.location = (-190, 334)
    node_HDRIprojection.location = (-415, 330)
    node_HDRItransform.location = (-642, 328)
    node_Visibility.location = (38, 18)
    node_RGBColor.location = (-182, 15)
    
    # Set RGB Color initial value to black
    node_RGBColor.a_value = (0, 0, 0)
    
    # Create links
    links.new(node_HDRIControls.outputs['Environment out'], node_OctaneWorld.inputs['Environment'])
    links.new(node_HDRI.outputs['Texture out'], node_HDRIControls.inputs['Texture'])
    links.new(node_HDRIprojection.outputs['Projection out'], node_HDRI.inputs['Projection'])
    links.new(node_HDRItransform.outputs['Transform out'], node_HDRIprojection.inputs['Sphere transformation'])
    links.new(node_Visibility.outputs['Environment out'], node_OctaneWorld.inputs['Visible Environment'])
    links.new(node_RGBColor.outputs['Texture out'], node_Visibility.inputs['Texture'])
    
    return {
        'world': world,
        'output': node_OctaneWorld,
        'controls': node_HDRIControls,
        'image': node_HDRI,
        'projection': node_HDRIprojection,
        'transform': node_HDRItransform,
        'visibility': node_Visibility,
        'rgb_color': node_RGBColor
    }
def load_hdri_octane(context, filepath, node_tree=None):
    """Load an HDRI into Octane's node setup"""
    if not node_tree:
        if not context.scene.world or not context.scene.world.use_nodes:
            return False
        node_tree = context.scene.world.node_tree
    
    # Find the RGB Image node
    hdri_node = None
    for node in node_tree.nodes:
        if node.type == 'OctaneRGBImage':
            hdri_node = node
            break
    
    if not hdri_node:
        return False
        
    try:
        # Set the image path
        hdri_node.a_filename = filepath
        return True
    except:
        return False
def convert_cycles_to_octane_rotation(cycles_rotation):
    """Convert Cycles rotation values to Octane rotation values"""
    # Note: May need adjustment based on exact rotation handling differences
    return (
        cycles_rotation[0],  # X
        cycles_rotation[1],  # Y
        cycles_rotation[2]   # Z
    )
def set_hdri_rotation_octane(context, rotation, node_tree=None):
    """Set HDRI rotation in Octane"""
    if not node_tree:
        if not context.scene.world or not context.scene.world.use_nodes:
            return False
        node_tree = context.scene.world.node_tree
    
    # Find the transform node
    transform_node = None
    for node in node_tree.nodes:
        if node.type == 'Octane3DTransformation':
            transform_node = node
            break
    
    if not transform_node:
        return False
        
    try:
        # Convert and set rotation
        octane_rotation = convert_cycles_to_octane_rotation(rotation)
        transform_node.inputs['Rotation'].default_value = octane_rotation
        return True
    except:
        return False
def set_hdri_power_octane(context, power, node_tree=None):
    """Set HDRI power/strength in Octane"""
    if not node_tree:
        if not context.scene.world or not context.scene.world.use_nodes:
            return False
        node_tree = context.scene.world.node_tree
    
    # Find the texture environment node
    env_node = None
    for node in node_tree.nodes:
        if node.type == 'OctaneTextureEnvironment':
            env_node = node
            break
    
    if not env_node:
        return False
        
    try:
        # Set power
        env_node.inputs['Power'].default_value = power
        return True
    except:
        return False
def get_active_hdri_octane(context):
    """Get the currently active HDRI path in Octane"""
    if not context.scene.world or not context.scene.world.use_nodes:
        return None
        
    for node in context.scene.world.node_tree.nodes:
        if node.type == 'OctaneRGBImage':
            return node.a_filename
            
    return None