import bpy

# Create or reuse a world named 'octane_world'
world = bpy.data.worlds.new(name='octane_world') if 'octane_world' not in bpy.data.worlds else bpy.data.worlds['octane_world']

# World settings
world.use_nodes = True

# Node tree setup
nodes = world.node_tree.nodes
links = world.node_tree.links

# Node: World Output.001
node_World Output.001 = nodes.new(type='OctaneEditorWorldOutputNode')
node_World Output.001.location = <Vector (260.4977, 334.4536)>
node_World Output.001.active = True
node_World Output.001.bl_description = ''
node_World Output.001.bl_height_default = 100.0
node_World Output.001.bl_height_max = 30.0
node_World Output.001.bl_height_min = 30.0
node_World Output.001.bl_icon = 'NONE'
node_World Output.001.bl_idname = 'OctaneEditorWorldOutputNode'
node_World Output.001.bl_label = 'World Output'
node_World Output.001.bl_rna = <bpy_struct, Struct("OctaneEditorWorldOutputNode") at 0x000001F04078EBE8>
node_World Output.001.bl_static_type = 'CUSTOM'
node_World Output.001.bl_width_default = 200.0
node_World Output.001.bl_width_max = 700.0
node_World Output.001.bl_width_min = 100.0
node_World Output.001.color = Color((0.699999988079071, 0.699999988079071, 0.699999988079071))
node_World Output.001.dimensions = Vector((200.0, 96.0))
node_World Output.001.height = 100.0
node_World Output.001.hide = False
node_World Output.001.inputs = bpy.data.worlds['octane_world'].node_tree.nodes["World Output.001"].inputs
node_World Output.001.internal_links = bpy.data.worlds['octane_world'].node_tree.nodes["World Output.001"].internal_links
node_World Output.001.label = ''
node_World Output.001.location = Vector((260.49774169921875, 334.45355224609375))
node_World Output.001.mute = False
node_World Output.001.name = 'World Output.001'
node_World Output.001.node_preview = bpy.data.worlds['octane_world'].node_tree
node_World Output.001.octane_color = (0.7, 0.7, 0.7, 0.7)
node_World Output.001.octane_socket_set = set()
node_World Output.001.outputs = bpy.data.worlds['octane_world'].node_tree.nodes["World Output.001"].outputs
node_World Output.001.parent = None
node_World Output.001.rna_type = bpy.data.worlds['octane_world'].node_tree
node_World Output.001.select = False
node_World Output.001.show_options = True
node_World Output.001.show_preview = False
node_World Output.001.show_texture = False
node_World Output.001.type = 'CUSTOM'
node_World Output.001.use_custom_color = False
node_World Output.001.warning_propagation = 'ALL'
node_World Output.001.width = 200.0

# Node: Texture environment
node_Texture environment = nodes.new(type='OctaneTextureEnvironment')
node_Texture environment.location = <Vector (38.7377, 333.8394)>
node_Texture environment.bl_description = ''
node_Texture environment.bl_height_default = 100.0
node_Texture environment.bl_height_max = 30.0
node_Texture environment.bl_height_min = 30.0
node_Texture environment.bl_icon = 'NONE'
node_Texture environment.bl_idname = 'OctaneTextureEnvironment'
node_Texture environment.bl_label = 'Texture environment'
node_Texture environment.bl_rna = <bpy_struct, Struct("OctaneTextureEnvironment") at 0x000001F04050AF68>
node_Texture environment.bl_static_type = 'CUSTOM'
node_Texture environment.bl_width_default = 200.0
node_Texture environment.bl_width_max = 700.0
node_Texture environment.bl_width_min = 100.0
node_Texture environment.color = Color((0.6079999804496765, 0.6079999804496765, 0.6079999804496765))
node_Texture environment.dimensions = Vector((200.0, 301.0))
node_Texture environment.height = 100.0
node_Texture environment.hide = False
node_Texture environment.inputs = bpy.data.worlds['octane_world'].node_tree.nodes["Texture environment"].inputs
node_Texture environment.internal_links = bpy.data.worlds['octane_world'].node_tree.nodes["Texture environment"].internal_links
node_Texture environment.label = ''
node_Texture environment.location = Vector((38.737709045410156, 333.83935546875))
node_Texture environment.mute = False
node_Texture environment.name = 'Texture environment'
node_Texture environment.node_preview = bpy.data.worlds['octane_world'].node_tree
node_Texture environment.octane_attribute_config = {}
node_Texture environment.octane_attribute_list = []
node_Texture environment.octane_min_version = 0
node_Texture environment.octane_node_type = 37
node_Texture environment.octane_render_pass_description = ''
node_Texture environment.octane_render_pass_id = -1
node_Texture environment.octane_render_pass_name = ''
node_Texture environment.octane_render_pass_short_name = ''
node_Texture environment.octane_render_pass_sub_type_name = ''
node_Texture environment.octane_socket_class_list = [<class 'octane.nodes.environments.texture_environment.OctaneTextureEnvironmentTexture'>, <class 'octane.nodes.environments.texture_environment.OctaneTextureEnvironmentPower'>, <class 'octane.nodes.environments.texture_environment.OctaneTextureEnvironmentImportanceSampling'>, <class 'octane.nodes.environments.texture_environment.OctaneTextureEnvironmentCastPhotons'>, <class 'octane.nodes.environments.texture_environment.OctaneTextureEnvironmentMedium'>, <class 'octane.nodes.environments.texture_environment.OctaneTextureEnvironmentMediumRadius'>, <class 'octane.nodes.environments.texture_environment.OctaneTextureEnvironmentLightPassMask'>, <class 'octane.nodes.environments.texture_environment.OctaneTextureEnvironmentGroupVisibleEnvironment'>, <class 'octane.nodes.environments.texture_environment.OctaneTextureEnvironmentVisibleEnvironmentBackplate'>, <class 'octane.nodes.environments.texture_environment.OctaneTextureEnvironmentVisibleEnvironmentReflections'>, <class 'octane.nodes.environments.texture_environment.OctaneTextureEnvironmentVisibleEnvironmentRefractions'>, <class 'octane.nodes.environments.texture_environment.OctaneTextureEnvironmentRotation'>]
node_Texture environment.octane_socket_list = ['Texture', 'Power', 'Importance sampling', 'Cast photons', 'Medium', 'Medium radius', 'Medium light pass mask', 'Backplate', 'Reflections', 'Refractions', '[Deprecated]Rotation']
node_Texture environment.octane_socket_set = {'Reflections', 'Texture', 'Medium radius', 'Importance sampling', 'Refractions', 'Power', 'Cast photons', 'Medium light pass mask', '[Deprecated]Rotation', 'Backplate', 'Medium'}
node_Texture environment.octane_static_pin_count = 10
node_Texture environment.outputs = bpy.data.worlds['octane_world'].node_tree.nodes["Texture environment"].outputs
node_Texture environment.parent = None
node_Texture environment.rna_type = bpy.data.worlds['octane_world'].node_tree
node_Texture environment.select = False
node_Texture environment.show_options = True
node_Texture environment.show_preview = False
node_Texture environment.show_texture = False
node_Texture environment.type = 'CUSTOM'
node_Texture environment.use_custom_color = False
node_Texture environment.warning_propagation = 'ALL'
node_Texture environment.width = 200.0

# Node: RGB image
node_RGB image = nodes.new(type='OctaneRGBImage')
node_RGB image.location = <Vector (-190.3312, 333.9641)>
node_RGB image.a_can_wrap_x = False
node_RGB image.a_can_wrap_y = False
node_RGB image.a_channel_format = 'Automatic'
node_RGB image.a_channel_format_enum_items_str = ''
node_RGB image.a_filename = ''
node_RGB image.a_ies_photometry_mode = 'IES_MAX_1'
node_RGB image.a_image_chosen_layer_name = ''
node_RGB image.a_image_file_type = 0
node_RGB image.a_image_flip = False
node_RGB image.a_image_layer_names = ''
node_RGB image.a_initial_color_space_selected = False
node_RGB image.a_legacy_png_gamma = False
node_RGB image.a_reload = False
node_RGB image.a_size = bpy.data.worlds['octane_world'].node_tree.nodes["RGB image"].a_size
node_RGB image.a_source_info = ''
node_RGB image.a_type = 0
node_RGB image.bl_description = ''
node_RGB image.bl_height_default = 100.0
node_RGB image.bl_height_max = 30.0
node_RGB image.bl_height_min = 30.0
node_RGB image.bl_icon = 'NONE'
node_RGB image.bl_idname = 'OctaneRGBImage'
node_RGB image.bl_label = 'RGB image'
node_RGB image.bl_rna = <bpy_struct, Struct("OctaneRGBImage") at 0x000001F0412B96E8>
node_RGB image.bl_static_type = 'CUSTOM'
node_RGB image.bl_width_default = 200.0
node_RGB image.bl_width_max = 700.0
node_RGB image.bl_width_min = 100.0
node_RGB image.color = Color((0.6079999804496765, 0.6079999804496765, 0.6079999804496765))
node_RGB image.dimensions = Vector((200.0, 282.0))
node_RGB image.frame_current = 0
node_RGB image.frame_duration = 0
node_RGB image.frame_offset = 0
node_RGB image.frame_start = 0
node_RGB image.height = 100.0
node_RGB image.hide = False
node_RGB image.image = None
node_RGB image.inputs = bpy.data.worlds['octane_world'].node_tree.nodes["RGB image"].inputs
node_RGB image.internal_links = bpy.data.worlds['octane_world'].node_tree.nodes["RGB image"].internal_links
node_RGB image.label = ''
node_RGB image.last_image_name = ''
node_RGB image.location = Vector((-190.3311767578125, 333.9640808105469))
node_RGB image.mute = False
node_RGB image.name = 'RGB image'
node_RGB image.node_preview = bpy.data.worlds['octane_world'].node_tree
node_RGB image.octane_attribute_list = ['a_initial_color_space_selected', 'a_legacy_png_gamma', 'a_ies_photometry_mode', 'a_channel_format']
node_RGB image.octane_socket_set = {'Border mode (U)', 'Border mode (V)', 'Legacy gamma', 'Invert', '[Deprecated]Scale', 'Power', 'Projection', 'Color space', 'Linear sRGB invert', '[Deprecated]Border mode', 'UV transform'}
node_RGB image.outputs = bpy.data.worlds['octane_world'].node_tree.nodes["RGB image"].outputs
node_RGB image.parent = None
node_RGB image.rna_type = bpy.data.worlds['octane_world'].node_tree
node_RGB image.select = False
node_RGB image.show_options = True
node_RGB image.show_preview = False
node_RGB image.show_texture = False
node_RGB image.tile = 0
node_RGB image.type = 'CUSTOM'
node_RGB image.use_auto_refresh = False
node_RGB image.use_custom_color = False
node_RGB image.use_cyclic = False
node_RGB image.warning_propagation = 'ALL'
node_RGB image.width = 200.0

# Node: Spherical Projection
node_Spherical Projection = nodes.new(type='OctaneSpherical')
node_Spherical Projection.location = <Vector (-415.2154, 330.2407)>
node_Spherical Projection.bl_description = ''
node_Spherical Projection.bl_height_default = 100.0
node_Spherical Projection.bl_height_max = 30.0
node_Spherical Projection.bl_height_min = 30.0
node_Spherical Projection.bl_icon = 'NONE'
node_Spherical Projection.bl_idname = 'OctaneSpherical'
node_Spherical Projection.bl_label = 'Spherical Projection'
node_Spherical Projection.bl_rna = <bpy_struct, Struct("OctaneSpherical") at 0x000001F03FDE8808>
node_Spherical Projection.bl_static_type = 'CUSTOM'
node_Spherical Projection.bl_width_default = 200.0
node_Spherical Projection.bl_width_max = 700.0
node_Spherical Projection.bl_width_min = 100.0
node_Spherical Projection.color = Color((0.6079999804496765, 0.6079999804496765, 0.6079999804496765))
node_Spherical Projection.dimensions = Vector((200.0, 101.0))
node_Spherical Projection.height = 100.0
node_Spherical Projection.hide = False
node_Spherical Projection.inputs = bpy.data.worlds['octane_world'].node_tree.nodes["Spherical Projection"].inputs
node_Spherical Projection.internal_links = bpy.data.worlds['octane_world'].node_tree.nodes["Spherical Projection"].internal_links
node_Spherical Projection.label = ''
node_Spherical Projection.location = Vector((-415.21539306640625, 330.24066162109375))
node_Spherical Projection.mute = False
node_Spherical Projection.name = 'Spherical Projection'
node_Spherical Projection.node_preview = bpy.data.worlds['octane_world'].node_tree
node_Spherical Projection.octane_attribute_config = {}
node_Spherical Projection.octane_attribute_list = []
node_Spherical Projection.octane_min_version = 0
node_Spherical Projection.octane_node_type = 77
node_Spherical Projection.octane_render_pass_description = ''
node_Spherical Projection.octane_render_pass_id = -1
node_Spherical Projection.octane_render_pass_name = ''
node_Spherical Projection.octane_render_pass_short_name = ''
node_Spherical Projection.octane_render_pass_sub_type_name = ''
node_Spherical Projection.octane_socket_class_list = [<class 'octane.nodes.projection.spherical.OctaneSphericalTransform'>, <class 'octane.nodes.projection.spherical.OctaneSphericalPositionType'>]
node_Spherical Projection.octane_socket_list = ['Sphere transformation', 'Coordinate space']
node_Spherical Projection.octane_socket_set = {'Sphere transformation', 'Coordinate space'}
node_Spherical Projection.octane_static_pin_count = 2
node_Spherical Projection.outputs = bpy.data.worlds['octane_world'].node_tree.nodes["Spherical Projection"].outputs
node_Spherical Projection.parent = None
node_Spherical Projection.rna_type = bpy.data.worlds['octane_world'].node_tree
node_Spherical Projection.select = False
node_Spherical Projection.show_options = True
node_Spherical Projection.show_preview = False
node_Spherical Projection.show_texture = False
node_Spherical Projection.type = 'CUSTOM'
node_Spherical Projection.use_custom_color = False
node_Spherical Projection.warning_propagation = 'ALL'
node_Spherical Projection.width = 200.0

# Node: 3D transformation
node_3D transformation = nodes.new(type='Octane3DTransformation')
node_3D transformation.location = <Vector (-641.9505, 327.6602)>
node_3D transformation.bl_description = ''
node_3D transformation.bl_height_default = 100.0
node_3D transformation.bl_height_max = 30.0
node_3D transformation.bl_height_min = 30.0
node_3D transformation.bl_icon = 'NONE'
node_3D transformation.bl_idname = 'Octane3DTransformation'
node_3D transformation.bl_label = '3D transformation'
node_3D transformation.bl_rna = <bpy_struct, Struct("Octane3DTransformation") at 0x000001F041E43D68>
node_3D transformation.bl_static_type = 'CUSTOM'
node_3D transformation.bl_width_default = 200.0
node_3D transformation.bl_width_max = 700.0
node_3D transformation.bl_width_min = 100.0
node_3D transformation.color = Color((0.6079999804496765, 0.6079999804496765, 0.6079999804496765))
node_3D transformation.dimensions = Vector((200.0, 331.0))
node_3D transformation.height = 100.0
node_3D transformation.hide = False
node_3D transformation.inputs = bpy.data.worlds['octane_world'].node_tree.nodes["3D transformation"].inputs
node_3D transformation.internal_links = bpy.data.worlds['octane_world'].node_tree.nodes["3D transformation"].internal_links
node_3D transformation.label = ''
node_3D transformation.location = Vector((-641.9505004882812, 327.66021728515625))
node_3D transformation.mute = False
node_3D transformation.name = '3D transformation'
node_3D transformation.node_preview = bpy.data.worlds['octane_world'].node_tree
node_3D transformation.octane_attribute_config = {'a_transform': [171, 'transform', 13]}
node_3D transformation.octane_attribute_list = []
node_3D transformation.octane_min_version = 0
node_3D transformation.octane_node_type = 27
node_3D transformation.octane_render_pass_description = ''
node_3D transformation.octane_render_pass_id = -1
node_3D transformation.octane_render_pass_name = ''
node_3D transformation.octane_render_pass_short_name = ''
node_3D transformation.octane_render_pass_sub_type_name = ''
node_3D transformation.octane_socket_class_list = [<class 'octane.nodes.transforms._3d_transformation.Octane3DTransformationRotationOrder'>, <class 'octane.nodes.transforms._3d_transformation.Octane3DTransformationRotation'>, <class 'octane.nodes.transforms._3d_transformation.Octane3DTransformationScale'>, <class 'octane.nodes.transforms._3d_transformation.Octane3DTransformationTranslation'>]
node_3D transformation.octane_socket_list = ['Rotation order', 'Rotation', 'Scale', 'Translation']
node_3D transformation.octane_socket_set = {'Translation', 'Rotation', 'Scale', 'Rotation order'}
node_3D transformation.octane_static_pin_count = 4
node_3D transformation.outputs = bpy.data.worlds['octane_world'].node_tree.nodes["3D transformation"].outputs
node_3D transformation.parent = None
node_3D transformation.rna_type = bpy.data.worlds['octane_world'].node_tree
node_3D transformation.select = False
node_3D transformation.show_options = True
node_3D transformation.show_preview = False
node_3D transformation.show_texture = False
node_3D transformation.type = 'CUSTOM'
node_3D transformation.use_custom_color = False
node_3D transformation.warning_propagation = 'ALL'
node_3D transformation.width = 200.0

# Node: Texture environment.001
node_Texture environment.001 = nodes.new(type='OctaneTextureEnvironment')
node_Texture environment.001.location = <Vector (38.7377, 18.3493)>
node_Texture environment.001.bl_description = ''
node_Texture environment.001.bl_height_default = 100.0
node_Texture environment.001.bl_height_max = 30.0
node_Texture environment.001.bl_height_min = 30.0
node_Texture environment.001.bl_icon = 'NONE'
node_Texture environment.001.bl_idname = 'OctaneTextureEnvironment'
node_Texture environment.001.bl_label = 'Texture environment'
node_Texture environment.001.bl_rna = <bpy_struct, Struct("OctaneTextureEnvironment") at 0x000001F04050AF68>
node_Texture environment.001.bl_static_type = 'CUSTOM'
node_Texture environment.001.bl_width_default = 200.0
node_Texture environment.001.bl_width_max = 700.0
node_Texture environment.001.bl_width_min = 100.0
node_Texture environment.001.color = Color((0.6079999804496765, 0.6079999804496765, 0.6079999804496765))
node_Texture environment.001.dimensions = Vector((200.0, 301.0))
node_Texture environment.001.height = 100.0
node_Texture environment.001.hide = False
node_Texture environment.001.inputs = bpy.data.worlds['octane_world'].node_tree.nodes["Texture environment.001"].inputs
node_Texture environment.001.internal_links = bpy.data.worlds['octane_world'].node_tree.nodes["Texture environment.001"].internal_links
node_Texture environment.001.label = ''
node_Texture environment.001.location = Vector((38.737709045410156, 18.34930419921875))
node_Texture environment.001.mute = False
node_Texture environment.001.name = 'Texture environment.001'
node_Texture environment.001.node_preview = bpy.data.worlds['octane_world'].node_tree
node_Texture environment.001.octane_attribute_config = {}
node_Texture environment.001.octane_attribute_list = []
node_Texture environment.001.octane_min_version = 0
node_Texture environment.001.octane_node_type = 37
node_Texture environment.001.octane_render_pass_description = ''
node_Texture environment.001.octane_render_pass_id = -1
node_Texture environment.001.octane_render_pass_name = ''
node_Texture environment.001.octane_render_pass_short_name = ''
node_Texture environment.001.octane_render_pass_sub_type_name = ''
node_Texture environment.001.octane_socket_class_list = [<class 'octane.nodes.environments.texture_environment.OctaneTextureEnvironmentTexture'>, <class 'octane.nodes.environments.texture_environment.OctaneTextureEnvironmentPower'>, <class 'octane.nodes.environments.texture_environment.OctaneTextureEnvironmentImportanceSampling'>, <class 'octane.nodes.environments.texture_environment.OctaneTextureEnvironmentCastPhotons'>, <class 'octane.nodes.environments.texture_environment.OctaneTextureEnvironmentMedium'>, <class 'octane.nodes.environments.texture_environment.OctaneTextureEnvironmentMediumRadius'>, <class 'octane.nodes.environments.texture_environment.OctaneTextureEnvironmentLightPassMask'>, <class 'octane.nodes.environments.texture_environment.OctaneTextureEnvironmentGroupVisibleEnvironment'>, <class 'octane.nodes.environments.texture_environment.OctaneTextureEnvironmentVisibleEnvironmentBackplate'>, <class 'octane.nodes.environments.texture_environment.OctaneTextureEnvironmentVisibleEnvironmentReflections'>, <class 'octane.nodes.environments.texture_environment.OctaneTextureEnvironmentVisibleEnvironmentRefractions'>, <class 'octane.nodes.environments.texture_environment.OctaneTextureEnvironmentRotation'>]
node_Texture environment.001.octane_socket_list = ['Texture', 'Power', 'Importance sampling', 'Cast photons', 'Medium', 'Medium radius', 'Medium light pass mask', 'Backplate', 'Reflections', 'Refractions', '[Deprecated]Rotation']
node_Texture environment.001.octane_socket_set = {'Reflections', 'Texture', 'Medium radius', 'Importance sampling', 'Refractions', 'Power', 'Cast photons', 'Medium light pass mask', '[Deprecated]Rotation', 'Backplate', 'Medium'}
node_Texture environment.001.octane_static_pin_count = 10
node_Texture environment.001.outputs = bpy.data.worlds['octane_world'].node_tree.nodes["Texture environment.001"].outputs
node_Texture environment.001.parent = None
node_Texture environment.001.rna_type = bpy.data.worlds['octane_world'].node_tree
node_Texture environment.001.select = False
node_Texture environment.001.show_options = True
node_Texture environment.001.show_preview = False
node_Texture environment.001.show_texture = False
node_Texture environment.001.type = 'CUSTOM'
node_Texture environment.001.use_custom_color = False
node_Texture environment.001.warning_propagation = 'ALL'
node_Texture environment.001.width = 200.0

# Node: RGB color
node_RGB color = nodes.new(type='OctaneRGBColor')
node_RGB color.location = <Vector (-182.2112, 15.3167)>
node_RGB color.a_value = Color((0.0, 0.0, 0.0))
node_RGB color.bl_description = ''
node_RGB color.bl_height_default = 100.0
node_RGB color.bl_height_max = 30.0
node_RGB color.bl_height_min = 30.0
node_RGB color.bl_icon = 'NONE'
node_RGB color.bl_idname = 'OctaneRGBColor'
node_RGB color.bl_label = 'RGB color'
node_RGB color.bl_rna = <bpy_struct, Struct("OctaneRGBColor") at 0x000001F0412BA168>
node_RGB color.bl_static_type = 'CUSTOM'
node_RGB color.bl_width_default = 200.0
node_RGB color.bl_width_max = 700.0
node_RGB color.bl_width_min = 100.0
node_RGB color.color = Color((0.6079999804496765, 0.6079999804496765, 0.6079999804496765))
node_RGB color.dimensions = Vector((200.0, 79.0))
node_RGB color.height = 100.0
node_RGB color.hide = False
node_RGB color.inputs = bpy.data.worlds['octane_world'].node_tree.nodes["RGB color"].inputs
node_RGB color.internal_links = bpy.data.worlds['octane_world'].node_tree.nodes["RGB color"].internal_links
node_RGB color.label = ''
node_RGB color.location = Vector((-182.21119689941406, 15.316741943359375))
node_RGB color.mute = False
node_RGB color.name = 'RGB color'
node_RGB color.node_preview = bpy.data.worlds['octane_world'].node_tree
node_RGB color.octane_socket_set = set()
node_RGB color.outputs = bpy.data.worlds['octane_world'].node_tree.nodes["RGB color"].outputs
node_RGB color.parent = None
node_RGB color.rna_type = bpy.data.worlds['octane_world'].node_tree
node_RGB color.select = False
node_RGB color.show_options = True
node_RGB color.show_preview = False
node_RGB color.show_texture = False
node_RGB color.type = 'CUSTOM'
node_RGB color.use_custom_color = False
node_RGB color.warning_propagation = 'ALL'
node_RGB color.width = 200.0

# Link setup
links.new(nodes['Texture environment'].outputs['Environment out'], nodes['World Output.001'].inputs['Environment'])

# Link setup
links.new(nodes['RGB image'].outputs['Texture out'], nodes['Texture environment'].inputs['Texture'])

# Link setup
links.new(nodes['Spherical Projection'].outputs['Projection out'], nodes['RGB image'].inputs['Projection'])

# Link setup
links.new(nodes['3D transformation'].outputs['Transform out'], nodes['Spherical Projection'].inputs['Sphere transformation'])

# Link setup
links.new(nodes['Texture environment.001'].outputs['Environment out'], nodes['World Output.001'].inputs['Visible Environment'])

# Link setup
links.new(nodes['RGB color'].outputs['Texture out'], nodes['Texture environment.001'].inputs['Texture'])

# Assign world to scene
bpy.context.scene.world = world
