"""
Quick HDRI Controls - Flamenco Integration
This should ensure that HDRIs swap to their full quality instances before submission is started.
"""
import os
import bpy
import sys
import inspect
import importlib
from bpy.app.handlers import persistent
from . import utils
from .core import original_paths

# Store original functions/methods for restoration
original_flamenco_submit = None
original_flamenco_submit_operator = None

# Store proxy state for restoration
proxy_state = {
    'cycles': {'path': None, 'image_name': None},
    'vray': {'path': None},
    'octane': {'path': None, 'image_name': None}
}

def switch_to_full_resolution_hdri(context):
    """Switch to full-resolution HDRI before submitting to Flamenco"""
    # Only need to do anything if proxy mode is set to 'VIEWPORT'
    if not hasattr(context.scene, "hdri_settings") or context.scene.hdri_settings.proxy_mode != 'VIEWPORT':
        print("HDRI Controls: No proxy conversion needed for Flamenco submission")
        return

    print("HDRI Controls: Preparing Flamenco submission - switching to full-resolution HDRI")

    # Get the current render engine to determine which implementation to use
    render_engine = context.scene.render.engine

    if render_engine == 'CYCLES':
        # Cycles implementation
        world = context.scene.world
        if world and world.use_nodes:
            # First find environment texture node
            env_tex = None
            for node in world.node_tree.nodes:
                if node.type == 'TEX_ENVIRONMENT' and node.image:
                    env_tex = node
                    break

            if env_tex and env_tex.image:
                # Get original path from tracking or use current path
                current_image = env_tex.image
                original_path = original_paths.get(current_image.name, current_image.filepath)

                # Only switch if we're using a proxy and have an original path
                if original_path and original_path != current_image.filepath:
                    # Store current state for restoration
                    proxy_state['cycles']['path'] = current_image.filepath
                    proxy_state['cycles']['image_name'] = current_image.name

                    # Switch to full resolution
                    try:
                        # Load original image
                        img = bpy.data.images.load(original_path, check_existing=True)
                        img.reload()  # Force reload to ensure latest version

                        # Replace in environment texture node
                        env_tex.image = img

                        # Force updates
                        if hasattr(env_tex, 'update'):
                            env_tex.update()
                        world.node_tree.update_tag()

                        print(f"HDRI Controls: Switched to full-resolution HDRI for Flamenco: {original_path}")
                    except Exception as e:
                        print(f"HDRI Controls: Error switching to full-resolution HDRI: {str(e)}")

    elif render_engine == 'VRAY_RENDER_RT':
        # V-Ray implementation
        vray_collection = bpy.data.collections.get("vRay HDRI Controls")
        if vray_collection:
            for obj in vray_collection.objects:
                if obj.type == 'LIGHT' and "VRayDomeLight" in obj.name:
                    node_tree = obj.data.node_tree
                    bitmap_node = node_tree.nodes.get("V-Ray Bitmap")

                    if bitmap_node and hasattr(bitmap_node, 'BitmapBuffer'):
                        current_file = bitmap_node.BitmapBuffer.file

                        # Get original path
                        original_path = original_paths.get(os.path.basename(current_file), None)

                        # Only switch if we have a real original
                        if original_path and original_path != current_file:
                            # Store current file for restoration
                            proxy_state['vray']['path'] = current_file

                            # Switch to full resolution
                            try:
                                bitmap_node.BitmapBuffer.file = original_path

                                # Force node update
                                if hasattr(bitmap_node, 'update'):
                                    bitmap_node.update()
                                if hasattr(node_tree, 'update_tag'):
                                    node_tree.update_tag()

                                print(f"HDRI Controls: Switched to full-resolution HDRI for Flamenco: {original_path}")
                            except Exception as e:
                                print(f"HDRI Controls: Error switching to full-resolution HDRI: {str(e)}")
                    break

    elif render_engine == 'octane':
        # Octane implementation
        world = context.scene.world
        if world and world.use_nodes:
            rgb_node = None
            for node in world.node_tree.nodes:
                if node.bl_idname == 'OctaneRGBImage':
                    rgb_node = node
                    break

            if rgb_node and rgb_node.image:
                # Get original path
                current_image = rgb_node.image
                original_path = original_paths.get(current_image.name, None)

                if not original_path and hasattr(rgb_node, 'a_filename'):
                    original_path = original_paths.get(os.path.basename(rgb_node.a_filename), rgb_node.a_filename)

                # Only switch if we have a real original
                if original_path and original_path != (rgb_node.a_filename if hasattr(rgb_node, 'a_filename') else current_image.filepath):
                    # Store current state for restoration
                    if hasattr(rgb_node, 'a_filename'):
                        proxy_state['octane']['path'] = rgb_node.a_filename
                    else:
                        proxy_state['octane']['path'] = current_image.filepath

                    proxy_state['octane']['image_name'] = current_image.name

                    # Switch to full resolution
                    try:
                        # Load original image
                        img = bpy.data.images.load(original_path, check_existing=True)
                        img.reload()  # Force reload

                        # Clear existing image first
                        rgb_node.image = None

                        # Set new image and filepath
                        rgb_node.image = img
                        if hasattr(rgb_node, 'a_filename'):
                            rgb_node.a_filename = original_path

                        # Force updates
                        if hasattr(rgb_node, 'update'):
                            rgb_node.update()
                        world.node_tree.update_tag()

                        print(f"HDRI Controls: Switched to full-resolution HDRI for Flamenco: {original_path}")
                    except Exception as e:
                        print(f"HDRI Controls: Error switching to full-resolution HDRI: {str(e)}")

def restore_hdri_proxies(context):
    """Restore HDRI proxies after Flamenco job is submitted"""
    # Only restore if proxy mode is still 'VIEWPORT'
    if not hasattr(context.scene, "hdri_settings") or context.scene.hdri_settings.proxy_mode != 'VIEWPORT':
        return

    # Get the current render engine
    render_engine = context.scene.render.engine

    print(f"HDRI Controls: Restoring HDRI proxies after Flamenco submission for {render_engine}")

    if render_engine == 'CYCLES':
        # Cycles implementation
        if proxy_state['cycles']['path'] and os.path.exists(proxy_state['cycles']['path']):
            world = context.scene.world
            if world and world.use_nodes:
                # Find environment texture node
                env_tex = None
                for node in world.node_tree.nodes:
                    if node.type == 'TEX_ENVIRONMENT':
                        env_tex = node
                        break

                if env_tex:
                    try:
                        # First try to find the image by name if we stored it
                        restored_image = None
                        if proxy_state['cycles']['image_name'] and proxy_state['cycles']['image_name'] in bpy.data.images:
                            restored_image = bpy.data.images[proxy_state['cycles']['image_name']]
                            if os.path.normpath(restored_image.filepath) != os.path.normpath(proxy_state['cycles']['path']):
                                # If the paths don't match, don't use this image
                                restored_image = None

                        # If not found by name, load it
                        if not restored_image:
                            restored_image = bpy.data.images.load(proxy_state['cycles']['path'], check_existing=True)

                        # Set in environment texture node
                        env_tex.image = restored_image

                        # Force updates
                        if hasattr(env_tex, 'update'):
                            env_tex.update()
                        world.node_tree.update_tag()

                        print(f"HDRI Controls: Restored Cycles proxy HDRI: {proxy_state['cycles']['path']}")

                        # Clear the stored proxy state
                        proxy_state['cycles']['path'] = None
                        proxy_state['cycles']['image_name'] = None
                    except Exception as e:
                        print(f"HDRI Controls: Error restoring Cycles proxy HDRI: {str(e)}")

    elif render_engine == 'VRAY_RENDER_RT':
        # V-Ray implementation
        if proxy_state['vray']['path'] and os.path.exists(proxy_state['vray']['path']):
            vray_collection = bpy.data.collections.get("vRay HDRI Controls")
            if vray_collection:
                for obj in vray_collection.objects:
                    if obj.type == 'LIGHT' and "VRayDomeLight" in obj.name:
                        node_tree = obj.data.node_tree
                        bitmap_node = node_tree.nodes.get("V-Ray Bitmap")

                        if bitmap_node and hasattr(bitmap_node, 'BitmapBuffer'):
                            try:
                                # Restore proxy
                                bitmap_node.BitmapBuffer.file = proxy_state['vray']['path']

                                # Force updates
                                if hasattr(bitmap_node, 'update'):
                                    bitmap_node.update()
                                if hasattr(node_tree, 'update_tag'):
                                    node_tree.update_tag()

                                print(f"HDRI Controls: Restored V-Ray proxy HDRI: {proxy_state['vray']['path']}")

                                # Clear the stored proxy state
                                proxy_state['vray']['path'] = None
                            except Exception as e:
                                print(f"HDRI Controls: Error restoring V-Ray proxy HDRI: {str(e)}")
                        break

    elif render_engine == 'octane':
        # Octane implementation
        if proxy_state['octane']['path'] and os.path.exists(proxy_state['octane']['path']):
            world = context.scene.world
            if world and world.use_nodes:
                rgb_node = None
                for node in world.node_tree.nodes:
                    if node.bl_idname == 'OctaneRGBImage':
                        rgb_node = node
                        break

                if rgb_node:
                    try:
                        # First try to find the image by name if we stored it
                        restored_image = None
                        if proxy_state['octane']['image_name'] and proxy_state['octane']['image_name'] in bpy.data.images:
                            restored_image = bpy.data.images[proxy_state['octane']['image_name']]
                            if hasattr(rgb_node, 'a_filename') and os.path.normpath(rgb_node.a_filename) != os.path.normpath(proxy_state['octane']['path']):
                                # If the paths don't match, don't use this image
                                restored_image = None

                        # If not found by name, load it
                        if not restored_image:
                            restored_image = bpy.data.images.load(proxy_state['octane']['path'], check_existing=True)

                        # Clear and set the image
                        rgb_node.image = None
                        rgb_node.image = restored_image

                        # Set the filename too if the property exists
                        if hasattr(rgb_node, 'a_filename'):
                            rgb_node.a_filename = proxy_state['octane']['path']

                        # Force updates
                        if hasattr(rgb_node, 'update'):
                            rgb_node.update()
                        world.node_tree.update_tag()

                        print(f"HDRI Controls: Restored Octane proxy HDRI: {proxy_state['octane']['path']}")

                        # Clear the stored proxy state
                        proxy_state['octane']['path'] = None
                        proxy_state['octane']['image_name'] = None
                    except Exception as e:
                        print(f"HDRI Controls: Error restoring Octane proxy HDRI: {str(e)}")

def patched_flamenco_submit(original_function):
    """Create a patched version of a Flamenco submit function"""
    def wrapper(*args, **kwargs):
        # Before submission, ensure full-resolution HDRIs are used
        print("HDRI Controls: Flamenco submission intercepted")

        # Try to get context from various sources
        context = None
        # First check if context is passed as an argument
        for arg in args:
            if isinstance(arg, bpy.types.Context):
                context = arg
                break

        # If context wasn't in args, check kwargs
        if context is None:
            context = kwargs.get('context')

        # Last resort, use bpy.context
        if context is None:
            context = bpy.context

        # Switch to full resolution HDRIs
        switch_to_full_resolution_hdri(context)

        # Call the original function
        result = original_function(*args, **kwargs)

        # Register a timer to restore proxies after a short delay
        # This ensures the Flamenco job is fully submitted before we restore
        bpy.app.timers.register(
            lambda: restore_hdri_proxies(context),
            first_interval=1.0
        )

        return result

    return wrapper

def find_flamenco_submit_function():
    """Find the Flamenco submit function by searching all loaded modules"""
    print("HDRI Controls: Searching for Flamenco submit function...")

    # Look for flamenco modules in sys.modules
    flamenco_modules = [m for m in sys.modules if 'flamenco' in m.lower()]
    print(f"HDRI Controls: Found potential Flamenco modules: {flamenco_modules}")

    # First search for the submit_job operator class
    for module_name in flamenco_modules:
        module = sys.modules[module_name]

        for name, obj in inspect.getmembers(module):
            # Look for classes that might be operators
            if inspect.isclass(obj) and hasattr(obj, 'bl_idname'):
                if obj.bl_idname and 'flamenco' in obj.bl_idname.lower() and 'submit' in obj.bl_idname.lower():
                    print(f"HDRI Controls: Found Flamenco submit operator: {obj.bl_idname}")

                    # Check if it has an execute method
                    if hasattr(obj, 'execute'):
                        return obj, 'execute'

                    # Or an invoke method
                    if hasattr(obj, 'invoke'):
                        return obj, 'invoke'

    # If we can't find a class, look for functions related to submission
    for module_name in flamenco_modules:
        module = sys.modules[module_name]

        for name, obj in inspect.getmembers(module):
            if inspect.isfunction(obj) and ('submit' in name.lower() or 'job' in name.lower()):
                print(f"HDRI Controls: Found potential Flamenco function: {name}")
                return obj, None

    # Last resort - try to find any function with flamenco and submit in the name
    for module_name in sys.modules.keys():
        if 'bpy' in module_name or 'bl_' in module_name:
            module = sys.modules[module_name]

            for name, obj in inspect.getmembers(module):
                if inspect.isfunction(obj) and 'flamenco' in name.lower() and 'submit' in name.lower():
                    print(f"HDRI Controls: Found potential Flamenco function in {module_name}: {name}")
                    return obj, None

    return None, None

def patch_flamenco_submit(target_obj, method_name=None):
    """Patch Flamenco's submit function/method to ensure full-resolution HDRIs are used"""
    global original_flamenco_submit

    if method_name:
        # Patching a method of a class
        print(f"HDRI Controls: Patching method {method_name} of {target_obj}")

        # Store the original method
        original_method = getattr(target_obj, method_name)
        original_flamenco_submit = original_method

        # Define the patched method
        def patched_method(self, context, *args, **kwargs):
            # Before submission, ensure full-resolution HDRIs are used
            print("HDRI Controls: Flamenco submission intercepted via method patch")
            switch_to_full_resolution_hdri(context)

            # Call the original method
            result = original_method(self, context, *args, **kwargs)

            # Restore proxy HDRIs after a short delay
            bpy.app.timers.register(
                lambda: restore_hdri_proxies(context),
                first_interval=1.0
            )

            return result

        # Replace the method
        setattr(target_obj, method_name, patched_method)
        print(f"HDRI Controls: Successfully patched {method_name} method")
        return True
    else:
        # Patching a function
        print(f"HDRI Controls: Patching function {target_obj.__name__}")

        # Store the original function
        original_flamenco_submit = target_obj

        # Create a patched version
        patched_function = patched_flamenco_submit(target_obj)

        # Replace the function in its module
        module = inspect.getmodule(target_obj)
        setattr(module, target_obj.__name__, patched_function)
        print(f"HDRI Controls: Successfully patched {target_obj.__name__} function")
        return True

def monkey_patch_flamenco_operators():
    """Find and patch all Flamenco-related operators that might submit jobs"""
    flamenco_operators = []

    # Find all operator classes that might be related to Flamenco job submission
    for cls in bpy.types.Operator.__subclasses__():
        if hasattr(cls, 'bl_idname') and 'flamenco' in cls.bl_idname.lower():
            if 'submit' in cls.bl_idname.lower() or 'job' in cls.bl_idname.lower():
                flamenco_operators.append(cls)
                print(f"HDRI Controls: Found Flamenco operator class: {cls.bl_idname}")

    # If we found operators, patch them
    if flamenco_operators:
        for op_cls in flamenco_operators:
            # Try to patch execute method
            if hasattr(op_cls, 'execute'):
                patch_flamenco_submit(op_cls, 'execute')

            # Try to patch invoke method
            if hasattr(op_cls, 'invoke'):
                patch_flamenco_submit(op_cls, 'invoke')

        return True

    return False

def install_flamenco_submit_overrides():
    """Attempt to patch or override Flamenco's job submission functions/methods"""
    # First try to find individual Flamenco submit functions
    submit_obj, method_name = find_flamenco_submit_function()

    if submit_obj and method_name:
        # Found a method of a class
        success = patch_flamenco_submit(submit_obj, method_name)
        if success:
            print("HDRI Controls: Successfully patched Flamenco submission method")
            return True
    elif submit_obj:
        # Found a function
        success = patch_flamenco_submit(submit_obj)
        if success:
            print("HDRI Controls: Successfully patched Flamenco submission function")
            return True

    # If we can't find a specific function, try to monkey patch all Flamenco operators
    success = monkey_patch_flamenco_operators()
    if success:
        print("HDRI Controls: Successfully monkey-patched Flamenco operators")
        return True

    print("HDRI Controls: Could not find Flamenco submission functions to patch")
    return False

def install_pre_save_handler():
    """Install a handler that runs before the file is saved to ensure full-resolution HDRIs"""
    @persistent
    def pre_save_handler(dummy):
        # Switch to full-resolution HDRI before saving
        switch_to_full_resolution_hdri(bpy.context)

        # Register a timer to restore proxies after the save completes
        bpy.app.timers.register(
            lambda: restore_hdri_proxies(bpy.context),
            first_interval=1.0
        )

    # Register the handler
    if pre_save_handler not in bpy.app.handlers.save_pre:
        bpy.app.handlers.save_pre.append(pre_save_handler)
        print("HDRI Controls: Registered pre-save handler to ensure full-resolution HDRIs")

def register_flamenco_handlers():
    """Register Flamenco-specific handlers"""
    # Attempt to install Flamenco submit overrides
    success = install_flamenco_submit_overrides()

    # Install pre-save handler as a backup approach
    install_pre_save_handler()

    # Add render handlers as a fallback
    if not success:
        print("HDRI Controls: Using render handlers as fallback for Flamenco integration")

        @persistent
        def pre_render_handler(dummy):
            switch_to_full_resolution_hdri(bpy.context)

        @persistent
        def post_render_handler(dummy):
            # Restore proxies after rendering
            bpy.app.timers.register(
                lambda: restore_hdri_proxies(bpy.context),
                first_interval=1.0
            )

        # Register the handlers
        if pre_render_handler not in bpy.app.handlers.render_pre:
            bpy.app.handlers.render_pre.append(pre_render_handler)
            print("HDRI Controls: Registered pre-render handler as fallback")

        if post_render_handler not in bpy.app.handlers.render_complete:
            bpy.app.handlers.render_complete.append(post_render_handler)
            print("HDRI Controls: Registered post-render handler as fallback")

def unregister_flamenco_handlers():
    """Unregister Flamenco-specific handlers"""
    global original_flamenco_submit

    # Restore original Flamenco submit function/method if it was patched
    if original_flamenco_submit:
        # TODO: Proper restoration of original functions
        # This is complex and would require tracking which function/method was patched
        original_flamenco_submit = None

    # Remove pre-save handler
    for handler in list(bpy.app.handlers.save_pre):
        if "pre_save_handler" in str(handler):
            bpy.app.handlers.save_pre.remove(handler)
            print("HDRI Controls: Removed pre-save handler")

    # Remove pre-render handler
    for handler in list(bpy.app.handlers.render_pre):
        if "pre_render_handler" in str(handler):
            bpy.app.handlers.render_pre.remove(handler)
            print("HDRI Controls: Removed pre-render handler")

    # Remove post-render handler
    for handler in list(bpy.app.handlers.render_complete):
        if "post_render_handler" in str(handler):
            bpy.app.handlers.render_complete.remove(handler)
            print("HDRI Controls: Removed post-render handler")
