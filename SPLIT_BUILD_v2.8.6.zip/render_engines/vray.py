"""
Quick HDRI Controls - V-Ray specific implementation
"""
import os
import re
import bpy
from bpy.utils import previews
from mathutils import Vector
from datetime import datetime
import tempfile
import shutil
from math import radians, degrees
import time

# Fix the import to use the parent module's hdri_management
from .. import hdri_management

# Import from parent module
from ..utils import get_hdri_previews, create_hdri_proxy
from ..core import original_paths

# Re-export common functions with local references
# to maintain compatibility with existing code
generate_previews = hdri_management.generate_previews
has_hdri_files = hdri_management.has_hdri_files
has_active_hdri = hdri_management.has_active_hdri
get_folders = hdri_management.get_folders


def debug_vray_dome_light():
    """Print detailed debug information about the VRay dome light"""
    print("\n=== VRay Dome Light Debug ===")

    vray_collection = bpy.data.collections.get("vRay HDRI Controls")
    if not vray_collection:
        print("VRay collection not found!")
        return

    print(f"VRay collection: {vray_collection.name}")

    # Find the dome light
    dome_light = None
    for obj in vray_collection.objects:
        if obj.type == 'LIGHT' and "VRayDomeLight" in obj.name:
            dome_light = obj
            break

    if not dome_light:
        print("VRayDomeLight not found in collection!")
        return

    print(f"Dome Light: {dome_light.name}")
    print(f"Rotation: X:{degrees(dome_light.rotation_euler.x):.1f}° Y:{degrees(dome_light.rotation_euler.y):.1f}° Z:{degrees(dome_light.rotation_euler.z):.1f}°")

    if not dome_light.data or not dome_light.data.node_tree:
        print("Dome light has no node tree!")
        return

    node_tree = dome_light.data.node_tree
    print(f"Node tree: {node_tree.name}")

    # Print all nodes
    print("\nNodes:")
    for node in node_tree.nodes:
        print(f"  • {node.name} ({node.bl_idname})")

        # For specific nodes, print more detail
        if node.name == "Light Dome":
            print("    Light Dome inputs:")
            for i, input in enumerate(node.inputs):
                try:
                    value = "N/A"
                    if hasattr(input, "value"):
                        value = input.value
                    elif hasattr(input, "default_value"):
                        value = input.default_value
                    print(f"      {i}: {input.name if hasattr(input, 'name') else 'unnamed'} = {value}")
                except Exception as e:
                    print(f"      {i}: Error accessing input: {str(e)}")

        elif node.name == "V-Ray Bitmap":
            print("    Bitmap attributes:")
            for attr in dir(node):
                if attr.startswith("__"):
                    continue
                try:
                    value = getattr(node, attr)
                    if attr == "BitmapBuffer" and hasattr(value, "file"):
                        print(f"      BitmapBuffer.file = {value.file}")
                    elif not callable(value) and not isinstance(value, (list, dict, set)):
                        print(f"      {attr} = {value}")
                except Exception:
                    pass

    print("=== End Debug Info ===\n")


def debug_vray_light_dome_inputs(context):
    """Print information about Light Dome node inputs to help with debugging"""
    vray_collection = bpy.data.collections.get("vRay HDRI Controls")
    if vray_collection:
        for obj in vray_collection.objects:
            if obj.type == 'LIGHT' and "VRayDomeLight" in obj.name:
                if obj.data and obj.data.node_tree:
                    light_dome = obj.data.node_tree.nodes.get("Light Dome")
                    if light_dome:
                        print("\n==== V-Ray Light Dome Inputs ====")
                        for i, input in enumerate(light_dome.inputs):
                            input_name = input.name if hasattr(input, 'name') else 'unnamed'
                            input_value = None
                            if hasattr(input, 'value'):
                                input_value = input.value
                            elif hasattr(input, 'default_value'):
                                input_value = input.default_value
                            print(f"Input #{i}: {input_name} = {input_value}")
                        print("================================\n")
                        return
    print("V-Ray: Light Dome node not found")


def cleanup_hdri_proxies():
    """Clean up old proxy files"""
    proxy_dir = os.path.join(tempfile.gettempdir(), 'hdri_proxies')
    if os.path.exists(proxy_dir):
        try:
            # Remove files older than 24 hours
            current_time = datetime.now().timestamp()
            for file in os.listdir(proxy_dir):
                file_path = os.path.join(proxy_dir, file)
                if os.path.isfile(file_path):
                    if current_time - os.path.getmtime(file_path) > 86400:  # 24 hours
                        os.remove(file_path)
        except Exception as e:
            print(f"Error cleaning proxies: {str(e)}")

def get_proxy_directory(filepath):
    """Get or create the proxy directory for the given HDRI file"""
    hdri_dir = os.path.dirname(filepath)
    proxy_dir = os.path.join(hdri_dir, 'proxies')
    os.makedirs(proxy_dir, exist_ok=True)
    return proxy_dir

def ensure_vray_setup():
    """Ensure V-Ray collection exists and return the dome light"""
    scene = bpy.context.scene

    # Check if V-Ray collection already exists
    vray_collection = bpy.data.collections.get("vRay HDRI Controls")

    if not vray_collection:
        # Append V-Ray collection from support file
        addon_dir = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
        vray_support_file = os.path.join(addon_dir, "misc", "vray", "vray_support.blend")

        # Ensure the support file exists
        if not os.path.exists(vray_support_file):
            # Try to find support file in alternative locations
            alt_support_file = os.path.join(addon_dir, "vray_support.blend")
            if os.path.exists(alt_support_file):
                vray_support_file = alt_support_file
                print(f"Using alternate support file path: {vray_support_file}")
            else:
                raise FileNotFoundError(f"V-Ray support file not found: {vray_support_file}")

        # Load the support file
        with bpy.data.libraries.load(vray_support_file, link=False) as (data_from, data_to):
            data_to.collections = ["vRay HDRI Controls"]

        # Link collection to scene if the collection was successfully loaded
        if data_to.collections and data_to.collections[0]:
            vray_collection = data_to.collections[0]
            scene.collection.children.link(vray_collection)
            print(f"Successfully loaded vRay HDRI Controls collection from {vray_support_file}")
        else:
            raise RuntimeError("Failed to load V-Ray HDRI Controls collection")

    # Get VRayDomeLight
    dome_light = None
    for obj in vray_collection.objects:
        if obj.type == 'LIGHT' and "VRayDomeLight" in obj.name:
            dome_light = obj
            break

    if not dome_light:
        raise Exception("VRayDomeLight not found in collection")

    return dome_light

def detect_hdri_resolution(filepath):
    """
    Detect HDRI resolution from filename or metadata.
    Returns tuple of (original_resolution, available_resolutions)
    """
    # Standard resolutions in pixels (width)
    STANDARD_RESOLUTIONS = {
        1024: "1k",
        2048: "2k",
        4096: "4k",
        6144: "6k",
        8192: "8k",
        16384: "16k"
    }

    # Resolution patterns in filenames
    RESOLUTION_PATTERNS = [
        r'[\-_](\d+)[kK]',  # Match _2k, -2K, etc.
        r'[\-_](\d+)p',     # Match _2048p, etc.
        r'[\-_](\d+)x\d+',  # Match _2048x1024, etc.
        r'(\d+)[kK]',       # Match 2k, 2K without separator
    ]

    def get_nearest_standard_resolution(pixels):
        """Convert pixel width to nearest standard resolution"""
        nearest = min(STANDARD_RESOLUTIONS.keys(),
                     key=lambda x: abs(x - pixels))
        return STANDARD_RESOLUTIONS[nearest]

    # First try to detect from filename
    filename = os.path.basename(filepath)
    base_name = os.path.splitext(filename)[0]

    for pattern in RESOLUTION_PATTERNS:
        match = re.search(pattern, base_name)
        if match:
            # Convert matched value to pixels
            value = match.group(1)
            if value.lower().endswith('k'):
                pixels = int(float(value[:-1]) * 1024)
            else:
                pixels = int(value)

            detected_res = get_nearest_standard_resolution(pixels)

            # Get base filename without resolution
            clean_name = re.sub(pattern, '', base_name)

            # Look for other available resolutions
            dir_path = os.path.dirname(filepath)
            available_res = []

            for f in os.listdir(dir_path):
                if f.startswith(clean_name) and f.endswith(os.path.splitext(filename)[1]):
                    for pat in RESOLUTION_PATTERNS:
                        res_match = re.search(pat, f)
                        if res_match:
                            res_value = res_match.group(1)
                            if res_value.lower().endswith('k'):
                                res_pixels = int(float(res_value[:-1]) * 1024)
                            else:
                                res_pixels = int(res_value)
                            available_res.append(get_nearest_standard_resolution(res_pixels))
                            break

            return detected_res, list(set(available_res))

    # If no resolution in filename, try to get from image metadata
    try:
        img = bpy.data.images.load(filepath, check_existing=True)
        width = img.size[0]
        detected_res = get_nearest_standard_resolution(width)
        # Clean up if image was newly loaded
        if img.users == 0:
            bpy.data.images.remove(img)
        return detected_res, [detected_res]
    except:
        return None, []

def ensure_world_nodes():
    """Ensure V-Ray setup is ready (using dome light instead of world nodes)"""
    # For V-Ray we use a dome light instead of world nodes
    dome_light = ensure_vray_setup()

    # Get the node tree and nodes
    node_tree = dome_light.data.node_tree

    # Find V-Ray specific nodes
    bitmap_node = node_tree.nodes.get("V-Ray Bitmap")
    light_dome_node = node_tree.nodes.get("Light Dome")

    if not bitmap_node or not light_dome_node:
        raise Exception("Required V-Ray nodes not found in dome light")

    # Return the dome light, bitmap node and light dome node
    # This is equivalent to returning mapping, env_tex, background in Cycles
    return dome_light, bitmap_node, light_dome_node

def setup_hdri_system(context):
    """Set up the V-Ray HDRI system"""
    addon_name = __package__.split('.')[0]
    preferences = context.preferences.addons[addon_name].preferences
    hdri_settings = context.scene.hdri_settings

    # Ensure V-Ray render handlers are registered
    print("V-Ray: Registering render handlers...")
    register_vray_handlers()
    print("V-Ray: Render handlers registered successfully")

    # Set scene color management defaults
    context.scene.display_settings.display_device = 'sRGB'
    if hasattr(context.scene, 'sequencer_colorspace_settings'):
        context.scene.sequencer_colorspace_settings.name = 'sRGB'

    # Check render engine
    if context.scene.render.engine != 'VRAY_RENDER_RT':
        # Automatically switch to V-Ray
        context.scene.render.engine = 'VRAY_RENDER_RT'
        return {'INFO'}, "Render engine switched to V-Ray"

    # Try to set the view transform but don't error if it's not available
    try:
        # Check if 'AgX' is available in the view transform options
        if 'AgX' in [item.identifier for item in context.scene.view_settings.bl_rna.properties['view_transform'].enum_items]:
            context.scene.view_settings.view_transform = 'AgX'
    except Exception as e:
        return {'WARNING'}, f"Could not set color transform: {str(e)}"

    # Verify HDRI directory exists and is accessible
    if not preferences.hdri_directory or not os.path.exists(preferences.hdri_directory):
        return {'ERROR'}, "HDRI directory not found. Please select a valid directory in preferences."

    # If current folder is not set or doesn't exist, reset to HDRI directory
    if not hdri_settings.current_folder or not os.path.exists(hdri_settings.current_folder):
        hdri_settings.current_folder = preferences.hdri_directory

    # Initialize proxy settings from preferences
    from ..utils import initialize_hdri_settings_from_preferences
    initialize_hdri_settings_from_preferences(context)

    # Setup V-Ray dome light
    try:
        dome_light = ensure_vray_setup()

        # Check if there are any HDRIs in the current directory
        if not has_hdri_files(context):
            return {'WARNING'}, "(Only shows if no direct HDRIs are preset - Access folders)"

        # Generate previews for the current directory
        enum_items = generate_previews(None, context)

        # If we have HDRIs, set the preview to the first one
        if len(enum_items) > 1:
            hdri_settings.hdri_preview = enum_items[1][0]

        # Ensure V-Ray render handlers are registered
        register_vray_handlers()

        # Force redraw of UI
        for area in context.screen.areas:
            area.tag_redraw()

        return {'INFO'}, "HDRI system initialized successfully"

    except Exception as e:
        return {'ERROR'}, f"Failed to setup HDRI system: {str(e)}"

def update_background_strength(self, context):
    """Debug version that prints detailed information"""
    print(f"V-Ray strength update called. Self type: {type(self)}")
    print(f"Current strength value: {self.background_strength}")

    # Original code from __init__vray.py
    vray_collection = bpy.data.collections.get("vRay HDRI Controls")
    if vray_collection:
        print(f"Found V-Ray collection: {vray_collection.name}")
        for obj in vray_collection.objects:
            if obj.type == 'LIGHT' and "VRayDomeLight" in obj.name:
                print(f"Found VRayDomeLight: {obj.name}")
                if obj.data and obj.data.node_tree:
                    light_dome = obj.data.node_tree.nodes.get("Light Dome")
                    if light_dome:
                        print(f"Found Light Dome node")
                        # Debug inputs
                        for i, input in enumerate(light_dome.inputs):
                            if hasattr(input, 'name'):
                                print(f"Input {i}: {input.name}")

                        # Try using the same approach as in original file
                        try:
                            print(f"Attempting to set Intensity to {self.background_strength}")
                            light_dome.inputs['Intensity'].value = self.background_strength
                            print("Successfully set intensity by name")
                        except Exception as e:
                            print(f"Error setting intensity by name: {str(e)}")
                            # Try alternative method
                            try:
                                light_dome.inputs[26].value = self.background_strength
                                print("Successfully set intensity by index 26")
                            except Exception as e2:
                                print(f"Error setting intensity by index: {str(e2)}")

                        # Force node update
                        try:
                            light_dome.update()
                            print("Called light_dome.update()")
                        except Exception as e:
                            print(f"Error updating node: {str(e)}")

                        # Force redraw
                        for area in context.screen.areas:
                            if area.type == 'VIEW_3D':
                                area.tag_redraw()
                                print("Redrawing 3D View")

                        break


def reset_strength(context):
    """Reset the strength of the VRayDomeLight to 1.0"""
    import time

    vray_collection = bpy.data.collections.get("vRay HDRI Controls")
    if vray_collection:
        for obj in vray_collection.objects:
            if obj.type == 'LIGHT' and "VRayDomeLight" in obj.name:
                light_data = obj.data
                if light_data and light_data.node_tree:
                    light_dome = light_data.node_tree.nodes.get("Light Dome")
                    if light_dome:
                        # Set intensity to 1.0 using index 26 directly
                        if len(light_dome.inputs) > 26:
                            light_dome.inputs[26].value = 1.0
                            print("V-Ray: Reset intensity to 1.0")

                            # Also update the hdri_settings value
                            context.scene.hdri_settings.background_strength = 1.0

                            # Force updates
                            if hasattr(light_dome, 'update'):
                                light_dome.update()
                            if hasattr(light_data.node_tree, 'update_tag'):
                                light_data.node_tree.update_tag()

                            # Store original material settings
                            original_material_settings = {}
                            for material_slot in obj.material_slots:
                                if material_slot.material:
                                    original_material_settings[material_slot.material.name] = {
                                        'diffuse_color': material_slot.material.diffuse_color.copy(),
                                    }

                            # Temporarily modify materials to force update
                            for material_slot in obj.material_slots:
                                if material_slot.material:
                                    original_color = material_slot.material.diffuse_color.copy()
                                    material_slot.material.diffuse_color = (
                                        original_color[0] * 0.99,
                                        original_color[1] * 0.99,
                                        original_color[2] * 0.99,
                                        original_color[3]
                                    )

                            # Small delay
                            time.sleep(0.1)

                            # Restore original material settings
                            for material_slot in obj.material_slots:
                                if material_slot.material and material_slot.material.name in original_material_settings:
                                    material_slot.material.diffuse_color = original_material_settings[material_slot.material.name]['diffuse_color']

                            # Force V-Ray update if available
                            if hasattr(bpy.context.scene, 'vray') and hasattr(bpy.context.scene.vray, 'Exporter'):
                                auto_save = bpy.context.scene.vray.Exporter.auto_save_render
                                bpy.context.scene.vray.Exporter.auto_save_render = not auto_save
                                time.sleep(0.1)
                                bpy.context.scene.vray.Exporter.auto_save_render = auto_save

                            # Force viewport update
                            for area in context.screen.areas:
                                if area.type == 'VIEW_3D':
                                    area.tag_redraw()

                            return {'FINISHED'}

    print("V-Ray: No VRay dome light found to reset strength")
    return {'CANCELLED'}

@bpy.app.handlers.persistent
def reload_original_for_render(dummy):
    """Handler to replace proxy with full-quality HDRI before rendering"""
    context = bpy.context
    settings = context.scene.hdri_settings

    print("V-Ray: reload_original_for_render handler called")

    # Only swap for 'VIEWPORT' proxy mode
    if settings.proxy_mode != 'VIEWPORT':
        print("V-Ray: Keeping current HDRI - not in VIEWPORT proxy mode")
        return

    vray_collection = bpy.data.collections.get("vRay HDRI Controls")
    if vray_collection:
        for obj in vray_collection.objects:
            if obj.type == 'LIGHT' and "VRayDomeLight" in obj.name:
                node_tree = obj.data.node_tree
                bitmap_node = node_tree.nodes.get("V-Ray Bitmap")

                if bitmap_node and hasattr(bitmap_node, 'BitmapBuffer'):
                    current_file = bitmap_node.BitmapBuffer.file

                    # Store the current file for restoring later
                    if not hasattr(context.scene, "vray_proxy_path"):
                        bpy.types.Scene.vray_proxy_path = bpy.props.StringProperty()
                    context.scene.vray_proxy_path = current_file

                    # Find original high-res file
                    original_path = original_paths.get(os.path.basename(current_file), None)

                    # If original path not found in tracking, try to determine by filename pattern
                    if not original_path:
                        # Check if we're in a proxies folder
                        dir_path = os.path.dirname(current_file)
                        if os.path.basename(dir_path).lower() == 'proxies':
                            # Get the parent folder (where originals should be)
                            parent_dir = os.path.dirname(dir_path)

                            # Get base filename without resolution marker
                            base_name = os.path.basename(current_file)
                            base_name = re.sub(r'_[1248][kK]', '', os.path.splitext(base_name)[0])
                            ext = os.path.splitext(current_file)[1]

                            # Look for matching files in parent dir
                            for f in os.listdir(parent_dir):
                                if f.startswith(base_name) and f.endswith(ext):
                                    potential_path = os.path.join(parent_dir, f)
                                    # Skip if it's another proxy
                                    if not re.search(r'_[1248][kK]', f):
                                        original_path = potential_path
                                        print(f"V-Ray: Found original by name pattern: {original_path}")
                                        break

                    # If we found an original, use it
                    if original_path and os.path.exists(original_path):
                        print(f"V-Ray: Swapping to full-quality HDRI for rendering: {original_path}")
                        bitmap_node.BitmapBuffer.file = original_path

                        # Force node update
                        bitmap_node.update()
                        # Force V-Ray to update if possible
                        if hasattr(node_tree, 'update_tag'):
                            node_tree.update_tag()
                    else:
                        print(f"V-Ray: No original found for {current_file}, using as-is for rendering")
                break

@bpy.app.handlers.persistent
def reset_proxy_after_render_complete(dummy):
    """Handler to reset to proxy after rendering completes"""
    context = bpy.context
    settings = context.scene.hdri_settings

    print("V-Ray: reset_proxy_after_render_complete handler called")

    # Only swap back for 'VIEWPORT' proxy mode
    if settings.proxy_mode != 'VIEWPORT':
        return

    # Check if we stored a proxy path
    if hasattr(context.scene, "vray_proxy_path") and context.scene.vray_proxy_path:
        proxy_path = context.scene.vray_proxy_path

        if proxy_path and os.path.exists(proxy_path):
            vray_collection = bpy.data.collections.get("vRay HDRI Controls")
            if vray_collection:
                for obj in vray_collection.objects:
                    if obj.type == 'LIGHT' and "VRayDomeLight" in obj.name:
                        node_tree = obj.data.node_tree
                        bitmap_node = node_tree.nodes.get("V-Ray Bitmap")

                        if bitmap_node and hasattr(bitmap_node, 'BitmapBuffer'):
                            print(f"V-Ray: Render complete, swapping back to proxy: {proxy_path}")
                            bitmap_node.BitmapBuffer.file = proxy_path

                            # Clear the stored path
                            context.scene.vray_proxy_path = ""

                            # Force node update
                            bitmap_node.update()
                            if hasattr(node_tree, 'update_tag'):
                                node_tree.update_tag()

                            break

@bpy.app.handlers.persistent
def reset_proxy_after_render(dummy):
    """Handler to reset to proxy after render cancellation"""
    context = bpy.context

    print("V-Ray: reset_proxy_after_render handler called")

    # Only process for V-Ray render engine
    if context.scene.render.engine != 'VRAY_RENDER_RT':
        print("V-Ray: Skipping handler - wrong engine")
        return

    # Find the V-Ray dome light
    vray_collection = bpy.data.collections.get("vRay HDRI Controls")
    if not vray_collection:
        print("V-Ray: Collection not found")
        return

    dome_light = None
    for obj in vray_collection.objects:
        if obj.type == 'LIGHT' and "VRayDomeLight" in obj.name:
            dome_light = obj
            break

    if not dome_light:
        print("V-Ray: Dome light not found")
        return

    # Get the bitmap node
    node_tree = dome_light.data.node_tree
    bitmap_node = node_tree.nodes.get("V-Ray Bitmap")

    if not bitmap_node or not hasattr(bitmap_node, 'BitmapBuffer') or not bitmap_node.BitmapBuffer:
        print("V-Ray: Bitmap node or buffer not found")
        return

    # Check for stored proxy path - try multiple sources
    proxy_path = None

    # Try custom attribute first
    if "temp_proxy_path" in bitmap_node:
        proxy_path = bitmap_node["temp_proxy_path"]
        print(f"V-Ray: Found proxy path in node attribute: {proxy_path}")
        # Remove the attribute
        del bitmap_node["temp_proxy_path"]

    # Try scene property as backup
    if proxy_path is None and "vray_temp_proxy_path" in context.scene:
        proxy_path = context.scene["vray_temp_proxy_path"]
        print(f"V-Ray: Found proxy path in scene property: {proxy_path}")
        # Remove the property
        del context.scene["vray_temp_proxy_path"]

    # If we have a valid proxy path, switch back to it
    if proxy_path and os.path.exists(proxy_path):
        print(f"V-Ray: Switching back to proxy: {proxy_path}")
        bitmap_node.BitmapBuffer.file = proxy_path

        # Force node update
        if hasattr(bitmap_node, 'update'):
            bitmap_node.update()
        if hasattr(node_tree, 'update_tag'):
            node_tree.update_tag()
    else:
        # If we can't find the stored proxy, try to create a new one
        print("V-Ray: Stored proxy not found, creating new proxy")
        current_file = bitmap_node.BitmapBuffer.file
        if os.path.exists(current_file):
            settings = context.scene.hdri_settings
            proxy_path = create_hdri_proxy(current_file, settings.proxy_resolution)
            if proxy_path and proxy_path != current_file:
                print(f"V-Ray: Created new proxy: {proxy_path}")
                # Store original path in tracking
                original_paths[os.path.basename(proxy_path)] = current_file
                # Switch to proxy
                bitmap_node.BitmapBuffer.file = proxy_path

                # Force node update
                if hasattr(bitmap_node, 'update'):
                    bitmap_node.update()
                if hasattr(node_tree, 'update_tag'):
                    node_tree.update_tag()



def update_hdri_proxy(self, context):
    """Update handler for proxy resolution and mode changes"""
    import time

    # V-Ray uses node tree in VRayDomeLight
    vray_collection = bpy.data.collections.get("vRay HDRI Controls")
    if not vray_collection:
        print("V-Ray Proxy Update: Collection not found")
        return

    dome_light = None
    for obj in vray_collection.objects:
        if obj.type == 'LIGHT' and "VRayDomeLight" in obj.name:
            dome_light = obj
            break

    if not dome_light:
        print("V-Ray Proxy Update: Dome light not found")
        return

    node_tree = dome_light.data.node_tree
    bitmap_node = node_tree.nodes.get("V-Ray Bitmap")
    light_dome_node = node_tree.nodes.get("Light Dome")

    if not bitmap_node:
        print("V-Ray Proxy Update: Bitmap node not found")
        return

    if not hasattr(bitmap_node, "BitmapBuffer") or not bitmap_node.BitmapBuffer:
        print("V-Ray Proxy Update: Bitmap node has no BitmapBuffer")
        return

    if not light_dome_node:
        print("V-Ray Proxy Update: Light Dome node not found")
        return

    # Close the proxy settings panel on change
    context.scene.hdri_settings.show_proxy_settings = False

    # Get current file path
    current_file = bitmap_node.BitmapBuffer.file
    print(f"V-Ray Proxy Update: Current file is {current_file}")

    if not current_file or not os.path.exists(current_file):
        print(f"V-Ray Proxy Update: Current file does not exist: {current_file}")
        return

    # Find the original high-resolution path
    original_path = None

    # Check all possible sources for original path
    if os.path.basename(current_file) in original_paths:
        original_path = original_paths[os.path.basename(current_file)]
    elif current_file in original_paths:
        original_path = original_paths[current_file]
    else:
        # Try to determine if current file is a proxy
        current_dir = os.path.dirname(current_file)
        current_basename = os.path.basename(current_file)

        if any(res in current_basename for res in ['_1K', '_2K', '_4K', '_6K', '_8K']):
            base_name = os.path.splitext(current_basename)[0]
            base_name = re.sub(r'_[1248]K', '', base_name)
            ext = os.path.splitext(current_basename)[1]

            parent_dir = os.path.dirname(current_dir)
            potential_dirs = [current_dir, parent_dir] if current_dir.endswith('proxies') else [current_dir]

            # Look in potential directories
            for search_dir in potential_dirs:
                if os.path.exists(search_dir):
                    potential_originals = [
                        f for f in os.listdir(search_dir)
                        if f.startswith(base_name) and f.endswith(ext)
                        and not any(res in f for res in ['_1K', '_2K', '_4K', '_6K', '_8K'])
                    ]

                    if potential_originals:
                        original_path = os.path.join(search_dir, potential_originals[0])
                        original_paths[os.path.basename(current_file)] = original_path
                        print(f"V-Ray Proxy Update: Found original: {original_path}")
                        break

        # If no original found, use current as original
        if not original_path:
            original_path = current_file
            print(f"V-Ray Proxy Update: Using current as original: {original_path}")

    # Ensure the original path exists
    if not original_path or not os.path.exists(original_path):
        print(f"V-Ray Proxy Update: Original file not found, using current")
        original_path = current_file

    # Store state of V-Ray viewport rendering
    vray_render_active = False
    if hasattr(bpy.context.scene, 'vray') and hasattr(bpy.context.scene.vray, 'Exporter'):
        vray_render_active = bpy.context.scene.vray.Exporter.auto_save_render

    # Apply proxy resolution to current HDRI
    resolution = context.scene.hdri_settings.proxy_resolution
    print(f"V-Ray Proxy Update: Target resolution: {resolution}")

    # Store original material settings to reapply later
    original_material_settings = {}
    if dome_light and dome_light.data:
        for material_slot in dome_light.material_slots:
            if material_slot.material:
                original_material_settings[material_slot.material.name] = {
                    'diffuse_color': material_slot.material.diffuse_color.copy(),
                }

    try:
        # Force V-Ray updates by modifying and restoring a material parameter
        # This will trigger a full V-Ray scene update
        for material_slot in dome_light.material_slots:
            if material_slot.material:
                # Temporarily modify material to force update
                original_color = material_slot.material.diffuse_color.copy()
                material_slot.material.diffuse_color = (
                    original_color[0] * 0.99,
                    original_color[1] * 0.99,
                    original_color[2] * 0.99,
                    original_color[3]
                )

        # Update the HDRI file
        if resolution == 'ORIGINAL':
            # Set to original file
            print(f"V-Ray Proxy Update: Setting to original file: {original_path}")
            bitmap_node.BitmapBuffer.file = original_path

            # Clean up tracking
            if current_file != original_path and os.path.basename(current_file) in original_paths:
                del original_paths[os.path.basename(current_file)]
        else:
            # Create and use proxy
            proxy_path = create_hdri_proxy(original_path, resolution)
            if proxy_path and os.path.exists(proxy_path):
                # Update tracking and set path
                original_paths[os.path.basename(proxy_path)] = original_path
                print(f"V-Ray Proxy Update: Setting to proxy: {proxy_path}")
                bitmap_node.BitmapBuffer.file = proxy_path
            else:
                print(f"V-Ray Proxy Update: Proxy creation failed, using original")
                bitmap_node.BitmapBuffer.file = original_path

        # Update node and force redraw
        if hasattr(bitmap_node, 'update'):
            bitmap_node.update()

        # Update intensity
        if len(light_dome_node.inputs) > 26:
            light_dome_node.inputs[26].value = context.scene.hdri_settings.background_strength
            light_dome_node.update()

        # Force entire node tree update
        node_tree.update_tag()

        # Sleep briefly to let updates process
        time.sleep(0.2)

        # Restore material settings to original
        for material_slot in dome_light.material_slots:
            if material_slot.material and material_slot.material.name in original_material_settings:
                material_slot.material.diffuse_color = original_material_settings[material_slot.material.name]['diffuse_color']

        # Update proxy mode handlers
        from ..utils import update_proxy_handlers
        update_proxy_handlers(context.scene.hdri_settings.proxy_mode)

        # Try to force a V-Ray update using any available methods
        if vray_render_active:
            if hasattr(bpy.ops, 'vray') and hasattr(bpy.ops.vray, 'update'):
                # Try running V-Ray update operator if available
                bpy.ops.vray.update()

            # If that doesn't work, try toggling auto_save_render
            if hasattr(bpy.context.scene.vray, 'Exporter'):
                # Toggle off and on again
                bpy.context.scene.vray.Exporter.auto_save_render = False
                time.sleep(0.2)
                bpy.context.scene.vray.Exporter.auto_save_render = True

        # Force viewport update
        for area in context.screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()

    except Exception as e:
        print(f"V-Ray Proxy Update: Error during update: {str(e)}")
        import traceback
        traceback.print_exc()

    print(f"V-Ray Proxy Update: Completed for resolution {resolution}")
    print(f"V-Ray Proxy Update: Current file path: {bitmap_node.BitmapBuffer.file}")

def toggle_hdri_visibility(context):
    """Toggle the visibility of the HDRI in V-Ray"""
    vray_collection = bpy.data.collections.get("vRay HDRI Controls")
    if vray_collection:
        for obj in vray_collection.objects:
            if obj.type == 'LIGHT' and "VRayDomeLight" in obj.name:
                # Get the light data and node tree
                light_data = obj.data
                if light_data and light_data.node_tree:
                    light_dome = light_data.node_tree.nodes.get("Light Dome")
                    if light_dome:
                        # Access input 27 directly for the Invisible parameter
                        if len(light_dome.inputs) > 27:
                            # Toggle the invisible input (True = invisible, False = visible)
                            current_value = light_dome.inputs[27].value
                            light_dome.inputs[27].value = not current_value

                            # Print debug info
                            visibility_state = "Invisible" if not current_value else "Visible"
                            print(f"V-Ray Visibility: Set to {visibility_state} (input[27] = {not current_value})")

                            # Force update
                            if hasattr(light_dome, 'update'):
                                light_dome.update()

                            # Force node tree update
                            if hasattr(light_data.node_tree, 'update_tag'):
                                light_data.node_tree.update_tag()

                            return not current_value  # Return new visibility state (True = visible, False = invisible)
                        else:
                            print(f"V-Ray Visibility: Light Dome doesn't have enough inputs (found {len(light_dome.inputs)}, need at least 28)")
                            print(f"V-Ray Visibility: Available inputs: {[i for i, inp in enumerate(light_dome.inputs) if inp.name]}")
                    else:
                        print("V-Ray Visibility: Light Dome node not found")
                else:
                    print("V-Ray Visibility: No node tree found for light")
                break
    else:
        print("V-Ray Visibility: V-Ray collection not found")

    return False
def get_hdri_visible(context):
    """Check if the HDRI is visible in V-Ray"""
    vray_collection = bpy.data.collections.get("vRay HDRI Controls")
    if vray_collection:
        for obj in vray_collection.objects:
            if obj.type == 'LIGHT' and "VRayDomeLight" in obj.name:
                light_data = obj.data
                if light_data and light_data.node_tree:
                    light_dome = light_data.node_tree.nodes.get("Light Dome")
                    if light_dome and len(light_dome.inputs) > 27:
                        # The visibility state is the inverse of the "Invisible" input
                        # False in input[27] means visible, True means invisible
                        return not light_dome.inputs[27].value

    # Default to visible if not found or can't determine
    return True

def get_current_hdri_path(context):
    """Get the path of the currently loaded HDRI in V-Ray"""
    vray_collection = bpy.data.collections.get("vRay HDRI Controls")
    if vray_collection:
        for obj in vray_collection.objects:
            if obj.type == 'LIGHT' and "VRayDomeLight" in obj.name:
                node_tree = obj.data.node_tree
                bitmap_node = node_tree.nodes.get("V-Ray Bitmap")
                if bitmap_node and hasattr(bitmap_node, 'BitmapBuffer'):
                    return bitmap_node.BitmapBuffer.file
    return None


def reset_rotation(context):
    """Reset the rotation of the VRayDomeLight to zero"""
    vray_collection = bpy.data.collections.get("vRay HDRI Controls")
    if vray_collection:
        for obj in vray_collection.objects:
            if obj.type == 'LIGHT' and "VRayDomeLight" in obj.name:
                # Reset all rotation axes to zero
                obj.rotation_euler = (0, 0, 0)
                print("V-Ray Rotation: Reset all rotation axes to 0")

                # Force viewport update
                context.view_layer.update()
                return {'FINISHED'}

    print("V-Ray Rotation: No VRay dome light found to reset rotation")
    return {'CANCELLED'}


def quick_rotate_hdri(context, axis, direction):
    """Quick rotate the HDRI for V-Ray"""
    # Get addon name properly
    addon_name = __package__.split('.')[0]

    # Correctly access the preferences
    preferences = context.preferences.addons[addon_name].preferences
    rotation_increment = preferences.rotation_increment

    print(f"V-Ray Rotation: Using rotation increment of {rotation_increment}° from preferences")

    vray_collection = bpy.data.collections.get("vRay HDRI Controls")
    if vray_collection:
        for obj in vray_collection.objects:
            if obj.type == 'LIGHT' and "VRayDomeLight" in obj.name:
                # Get current rotation value in degrees
                current_rotation_rad = obj.rotation_euler[axis]
                current_rotation_deg = degrees(current_rotation_rad)
                print(f"V-Ray Rotation: Current rotation on axis {axis}: {current_rotation_deg:.2f}°")

                if direction == -99:  # Reset
                    # Set rotation directly to 0 for the specified axis
                    obj.rotation_euler[axis] = 0
                    print(f"V-Ray Rotation: Reset rotation on axis {axis} to 0°")
                else:  # Regular rotation
                    # Convert increment from degrees to radians
                    increment_radians = radians(rotation_increment)

                    # Calculate new rotation
                    new_rotation_rad = current_rotation_rad + (direction * increment_radians)
                    new_rotation_deg = degrees(new_rotation_rad)

                    # Apply the new rotation
                    obj.rotation_euler[axis] = new_rotation_rad
                    print(f"V-Ray Rotation: Changed rotation on axis {axis} from {current_rotation_deg:.2f}° to {new_rotation_deg:.2f}° using increment {rotation_increment}°")

                # Force viewport update
                context.view_layer.update()
                return {'FINISHED'}

    print("V-Ray Rotation: No VRay dome light found")
    return {'CANCELLED'}

def parse_changelog(changelog_path, current_version):
    """Parse CHANGELOG.md and return the entry for the current version"""
    try:
        with open(changelog_path, 'r') as f:
            content = f.read()

        # Convert version tuple to string format
        version_str = f"V{'.'.join(map(str, current_version))}"

        # Split content into version blocks
        version_blocks = content.split('\n## ')

        for block in version_blocks:
            # Skip empty blocks
            if not block.strip():
                continue

            # Check if this block matches our version
            if version_str in block:
                # Return the entire block
                return block.strip()

        return None
    except Exception as e:
        print(f"Error reading changelog: {str(e)}")
        return None

def get_hdri_metadata(filepath):
    """Extract metadata from HDRI image"""
    if not filepath or not os.path.exists(filepath):
        return None

    try:
        # Load image temporarily to get metadata
        img = bpy.data.images.load(filepath, check_existing=True)

        metadata = {
            'filename': os.path.basename(filepath),
            'resolution': f"{img.size[0]}x{img.size[1]}",
            'color_space': img.colorspace_settings.name,
            'file_format': img.file_format,
            'channels': img.channels,
            'file_size': os.path.getsize(filepath),
            'filepath': filepath,
        }

        # Convert file size to human-readable format
        if metadata['file_size']:
            size_bytes = metadata['file_size']
            for unit in ['B', 'KB', 'MB', 'GB']:
                if size_bytes < 1024:
                    metadata['file_size'] = f"{size_bytes:.1f} {unit}"
                    break
                size_bytes /= 1024

        # Clean up image if it was newly loaded
        if img.users == 0:
            bpy.data.images.remove(img)

        return metadata

    except Exception as e:
        print(f"Error getting metadata for {filepath}: {str(e)}")
        return None

def delete_world(context):
    """Delete the V-Ray HDRI setup"""
    vray_collection = bpy.data.collections.get("vRay HDRI Controls")
    if vray_collection:
        # First try to unlink the collection from all scenes
        for scene in bpy.data.scenes:
            try:
                if vray_collection.name in scene.collection.children:
                    scene.collection.children.unlink(vray_collection)
                    print(f"V-Ray Delete: Unlinked collection from scene {scene.name}")
            except Exception as e:
                print(f"V-Ray Delete: Error unlinking from scene: {str(e)}")

        # Store objects and lights to remove
        objects_to_remove = []
        lights_to_remove = []

        # Gather the objects first, without changing the collection during iteration
        for obj in vray_collection.objects:
            obj_name = obj.name  # Store name before removal
            objects_to_remove.append((obj, obj_name))
            if obj.data and obj.type == 'LIGHT':
                lights_to_remove.append((obj.data, obj.data.name))

        # Clear objects from collection
        for obj, obj_name in objects_to_remove:
            try:
                vray_collection.objects.unlink(obj)
                print(f"V-Ray Delete: Unlinked object {obj_name}")
            except Exception as e:
                print(f"V-Ray Delete: Error unlinking object: {str(e)}")

            try:
                bpy.data.objects.remove(obj)
                print(f"V-Ray Delete: Removed object {obj_name}")
            except Exception as e:
                print(f"V-Ray Delete: Error removing object: {str(e)}")

        # Remove light data
        for light, light_name in lights_to_remove:
            try:
                bpy.data.lights.remove(light)
                print(f"V-Ray Delete: Removed light {light_name}")
            except Exception as e:
                print(f"V-Ray Delete: Error removing light: {str(e)}")

        # Finally remove the collection
        try:
            collection_name = vray_collection.name
            bpy.data.collections.remove(vray_collection)
            print(f"V-Ray Delete: Removed V-Ray collection {collection_name}")
        except Exception as e:
            print(f"V-Ray Delete: Error removing collection: {str(e)}")

        return True
    else:
        print("V-Ray Delete: V-Ray collection not found")
        return False

def update_hdri_rotation(context, axis, value):
    """Update the rotation of the V-Ray dome light"""
    vray_collection = bpy.data.collections.get("vRay HDRI Controls")
    if vray_collection:
        for obj in vray_collection.objects:
            if obj.type == 'LIGHT' and "VRayDomeLight" in obj.name:
                obj.rotation_euler[axis] = value
                break

def set_hdri(context, filepath):
    """Load a new HDRI into V-Ray"""
    vray_collection = bpy.data.collections.get("vRay HDRI Controls")
    if not vray_collection:
        return False

    dome_light = None
    for obj in vray_collection.objects:
        if obj.type == 'LIGHT' and "VRayDomeLight" in obj.name:
            dome_light = obj
            break

    if not dome_light:
        return False

    node_tree = dome_light.data.node_tree
    bitmap_node = node_tree.nodes.get("V-Ray Bitmap")
    light_dome_node = node_tree.nodes.get("Light Dome")

    if not bitmap_node or not light_dome_node:
        return False

    # Get settings
    hdri_settings = context.scene.hdri_settings
    addon_name = __package__.split('.')[0]
    preferences = context.preferences.addons[addon_name].preferences

    # Store previous state - Always store the original file path, not proxy
    current_file = bitmap_node.BitmapBuffer.file if hasattr(bitmap_node.BitmapBuffer, 'file') else ''
    current_file = original_paths.get(os.path.basename(current_file), current_file)

    if current_file and current_file != filepath:
        # Store previous state using original file path
        hdri_settings.previous_hdri_path = current_file
        if len(light_dome_node.inputs) > 26:
            hdri_settings.previous_strength = light_dome_node.inputs[26].value
        else:
            hdri_settings.previous_strength = 1.0
        hdri_settings.previous_rotation = dome_light.rotation_euler.copy()

    # Store current rotation if keep_rotation is enabled
    current_rotation = None
    if preferences.keep_rotation:
        current_rotation = dome_light.rotation_euler.copy()
        print(f"V-Ray Keep Rotation: Storing current rotation {[degrees(r) for r in current_rotation]}")

    # Always store the original filepath in our tracking
    original_paths[os.path.basename(filepath)] = filepath

    # Check if V-Ray viewport rendering is active - temporarily disable if needed
    vray_render_active = False
    if hasattr(bpy.context.scene, 'vray') and hasattr(bpy.context.scene.vray, 'Exporter'):
        vray_render_active = bpy.context.scene.vray.Exporter.auto_save_render
        if vray_render_active:
            bpy.context.scene.vray.Exporter.auto_save_render = False
            time.sleep(0.2)  # Give it a moment

    # Load the HDRI - Use proxy if enabled
    try:
        if hdri_settings.proxy_resolution != 'ORIGINAL':
            proxy_path = create_hdri_proxy(filepath, hdri_settings.proxy_resolution)
            if proxy_path and os.path.exists(proxy_path):
                # Store original path mapping before loading proxy
                original_paths[os.path.basename(proxy_path)] = filepath
                bitmap_node.BitmapBuffer.file = proxy_path
            else:
                # Fallback to original if proxy creation fails
                bitmap_node.BitmapBuffer.file = filepath
        else:
            # Load original directly
            bitmap_node.BitmapBuffer.file = filepath

        # Apply rotation based on keep_rotation setting
        if preferences.keep_rotation and current_rotation is not None:
            print(f"V-Ray Keep Rotation: Applying stored rotation {[degrees(r) for r in current_rotation]}")
            dome_light.rotation_euler = current_rotation
        else:
            print("V-Ray Keep Rotation: Resetting to zero (keep_rotation is disabled)")
            dome_light.rotation_euler = (0, 0, 0)

        # Set intensity using index 26 directly
        if len(light_dome_node.inputs) > 26:
            light_dome_node.inputs[26].value = hdri_settings.background_strength
            print(f"V-Ray Strength: Set Intensity input[26] to {hdri_settings.background_strength}")

            # Store original material settings to reapply later
            # This creates a small change to force V-Ray to update
            original_material_settings = {}
            for material_slot in dome_light.material_slots:
                if material_slot.material:
                    original_material_settings[material_slot.material.name] = {
                        'diffuse_color': material_slot.material.diffuse_color.copy(),
                    }

            # Make a small change to force V-Ray to update
            for material_slot in dome_light.material_slots:
                if material_slot.material:
                    # Temporarily modify material to force update
                    original_color = material_slot.material.diffuse_color.copy()
                    material_slot.material.diffuse_color = (
                        original_color[0] * 0.99,
                        original_color[1] * 0.99,
                        original_color[2] * 0.99,
                        original_color[3]
                    )

            # Small delay to let changes process
            time.sleep(0.1)

            # Restore original material settings
            for material_slot in dome_light.material_slots:
                if material_slot.material and material_slot.material.name in original_material_settings:
                    material_slot.material.diffuse_color = original_material_settings[material_slot.material.name]['diffuse_color']

        # Force node updates
        if hasattr(bitmap_node, 'update'):
            bitmap_node.update()
        if hasattr(node_tree, 'update_tag'):
            node_tree.update_tag()

        # Restore V-Ray viewport rendering if it was active
        if vray_render_active:
            time.sleep(0.2)
            bpy.context.scene.vray.Exporter.auto_save_render = True

        # Force viewport update
        for area in bpy.context.screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()

        return True
    except Exception as e:
        print(f"Failed to load HDRI in V-Ray: {str(e)}")
        import traceback
        traceback.print_exc()

        # Make sure to re-enable V-Ray rendering if we had an error
        if vray_render_active:
            bpy.context.scene.vray.Exporter.auto_save_render = True

        return False

def reset_hdri(context):
    """Reset to previously selected HDRI in V-Ray"""
    hdri_settings = context.scene.hdri_settings
    addon_name = __package__.split('.')[0]
    preferences = context.preferences.addons[addon_name].preferences

    # Check if we have a previous HDRI to restore
    if not hdri_settings.previous_hdri_path:
        return {'WARNING'}, "No previous HDRI to restore"

    # Verify the file still exists
    if not os.path.exists(hdri_settings.previous_hdri_path):
        return {'ERROR'}, "Previous HDRI file could not be found"

    try:
        # Find the V-Ray dome light
        vray_collection = bpy.data.collections.get("vRay HDRI Controls")
        if not vray_collection:
            return {'ERROR'}, "V-Ray collection not found"

        dome_light = None
        for obj in vray_collection.objects:
            if obj.type == 'LIGHT' and "VRayDomeLight" in obj.name:
                dome_light = obj
                break

        if not dome_light:
            return {'ERROR'}, "VRayDomeLight not found"

        node_tree = dome_light.data.node_tree
        bitmap_node = node_tree.nodes.get("V-Ray Bitmap")
        light_dome_node = node_tree.nodes.get("Light Dome")

        if not bitmap_node or not light_dome_node:
            return {'ERROR'}, "V-Ray nodes not found"

        # Store current state before making changes
        current_file = bitmap_node.BitmapBuffer.file if hasattr(bitmap_node.BitmapBuffer, 'file') else ''
        reset_to_path = hdri_settings.previous_hdri_path
        reset_to_path = original_paths.get(os.path.basename(reset_to_path), reset_to_path)

        # Store V-Ray viewport rendering state
        vray_render_active = False
        if hasattr(bpy.context.scene, 'vray') and hasattr(bpy.context.scene.vray, 'Exporter'):
            vray_render_active = bpy.context.scene.vray.Exporter.auto_save_render
            # Temporarily disable rendering
            if vray_render_active:
                bpy.context.scene.vray.Exporter.auto_save_render = False
                time.sleep(0.2)  # Give it a moment

        # Load the appropriate version (proxy or original)
        if hdri_settings.proxy_resolution != 'ORIGINAL':
            # Create and load proxy
            proxy_path = create_hdri_proxy(reset_to_path, hdri_settings.proxy_resolution)
            if proxy_path:
                # Store original path mapping
                original_paths[os.path.basename(proxy_path)] = reset_to_path
                bitmap_node.BitmapBuffer.file = proxy_path
            else:
                # Fallback to original if proxy creation fails
                bitmap_node.BitmapBuffer.file = reset_to_path
        else:
            # Load original
            bitmap_node.BitmapBuffer.file = reset_to_path

        # Update the preview selection
        enum_items = generate_previews(None, context)
        preview_found = False

        # First try to find exact match
        for item in enum_items:
            if not item[0]:  # Skip empty item
                continue
            if os.path.normpath(item[0]) == os.path.normpath(reset_to_path):
                hdri_settings.hdri_preview = item[0]
                preview_found = True
                break

        # If no exact match found, try matching by basename
        if not preview_found:
            reset_basename = os.path.basename(reset_to_path)
            for item in enum_items:
                if not item[0]:  # Skip empty item
                    continue
                if os.path.basename(item[0]) == reset_basename:
                    hdri_settings.hdri_preview = item[0]
                    preview_found = True
                    break

        # Update previous HDRI path to the one we just replaced
        hdri_settings.previous_hdri_path = current_file

        # Restore previous strength if available
        if hasattr(hdri_settings, 'previous_strength'):
            try:
                # Use index 26 directly for the intensity input
                if len(light_dome_node.inputs) > 26:
                    light_dome_node.inputs[26].value = hdri_settings.previous_strength
                    print(f"V-Ray Reset: Restored intensity input[26] to {hdri_settings.previous_strength}")

                    # Force node update
                    if hasattr(light_dome_node, 'update'):
                        light_dome_node.update()

                    # Store original material settings
                    original_material_settings = {}
                    for material_slot in dome_light.material_slots:
                        if material_slot.material:
                            original_material_settings[material_slot.material.name] = {
                                'diffuse_color': material_slot.material.diffuse_color.copy(),
                            }

                    # Temporarily modify materials to force update
                    for material_slot in dome_light.material_slots:
                        if material_slot.material:
                            original_color = material_slot.material.diffuse_color.copy()
                            material_slot.material.diffuse_color = (
                                original_color[0] * 0.99,
                                original_color[1] * 0.99,
                                original_color[2] * 0.99,
                                original_color[3]
                            )

                    # Small delay
                    time.sleep(0.1)

                    # Restore original material settings
                    for material_slot in dome_light.material_slots:
                        if material_slot.material and material_slot.material.name in original_material_settings:
                            material_slot.material.diffuse_color = original_material_settings[material_slot.material.name]['diffuse_color']
            except Exception as e:
                print(f"V-Ray Reset: Could not restore strength: {str(e)}")

        # Restore previous rotation if available
        if hasattr(hdri_settings, 'previous_rotation'):
            try:
                dome_light.rotation_euler = hdri_settings.previous_rotation
            except Exception as e:
                print(f"V-Ray Reset HDRI: Could not restore rotation: {str(e)}")

        # Only update current folder if there's no active search
        if not hdri_settings.search_query:
            # Update current folder to the directory of the previous HDRI
            previous_hdri_dir = os.path.dirname(reset_to_path)
            base_dir = os.path.normpath(os.path.abspath(preferences.hdri_directory))

            # Ensure the new folder is within the base HDRI directory
            try:
                rel_path = os.path.relpath(previous_hdri_dir, base_dir)
                if not rel_path.startswith('..'):
                    hdri_settings.current_folder = previous_hdri_dir
                else:
                    # If somehow outside base directory, reset to base
                    hdri_settings.current_folder = base_dir
            except ValueError:
                # Fallback if path comparison fails
                hdri_settings.current_folder = base_dir

        # Clear preview cache for folder change
        from ..utils import get_hdri_previews
        get_hdri_previews.cached_dir = None
        get_hdri_previews.cached_items = []

        # Force node tree update
        if hasattr(node_tree, 'update_tag'):
            node_tree.update_tag()

        # Update bitmap node
        if hasattr(bitmap_node, 'update'):
            bitmap_node.update()

        # Restore V-Ray viewport rendering if active
        if vray_render_active:
            time.sleep(0.2)  # Wait a moment
            bpy.context.scene.vray.Exporter.auto_save_render = True

        # Force redraw of viewport
        for area in context.screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()

        return {'INFO'}, "HDRI reset successful"

    except Exception as e:
        print(f"Reset HDRI error: {str(e)}")
        import traceback
        traceback.print_exc()
        return {'ERROR'}, f"Failed to reset HDRI: {str(e)}"

def previous_hdri(context):
    """Load the previous HDRI in the current folder for V-Ray"""
    hdri_settings = context.scene.hdri_settings
    enum_items = generate_previews(None, context)

    # Check if we have any items besides 'None'
    if len(enum_items) <= 1:
        return {'INFO'}, "No HDRIs available in current folder"

    # Find current HDRI index
    current_index = -1
    for i, item in enumerate(enum_items):
        if item[0] == hdri_settings.hdri_preview:
            current_index = i
            break

    # Get previous HDRI (skip the first 'None' item)
    if current_index > 1:
        hdri_settings.hdri_preview = enum_items[current_index - 1][0]
    elif current_index == 1:  # If at first HDRI, wrap to last
        hdri_settings.hdri_preview = enum_items[-1][0]

    return {'FINISHED'}

def next_hdri(context):
    """Load the next HDRI in the current folder for V-Ray"""
    hdri_settings = context.scene.hdri_settings
    enum_items = generate_previews(None, context)

    # Check if we have any items besides 'None'
    if len(enum_items) <= 1:
        return {'INFO'}, "No HDRIs available in current folder"

    # Find current HDRI index
    current_index = -1
    for i, item in enumerate(enum_items):
        if item[0] == hdri_settings.hdri_preview:
            current_index = i
            break

    # Get next HDRI (skip the first 'None' item)
    if current_index >= 0 and current_index < len(enum_items) - 1:
        hdri_settings.hdri_preview = enum_items[current_index + 1][0]
    elif current_index == len(enum_items) - 1:  # If at last HDRI, wrap to first
        # Make sure we have a valid item to wrap to
        if len(enum_items) > 1:
            hdri_settings.hdri_preview = enum_items[1][0]  # Skip 'None' item

    return {'FINISHED'}


@bpy.app.handlers.persistent
def reset_proxy_after_render(dummy):
    """Handler to reset to proxy after render cancellation"""
    context = bpy.context
    settings = context.scene.hdri_settings

    print("V-Ray: reset_proxy_after_render called")

    # Only swap back for 'VIEWPORT' proxy mode
    if settings.proxy_mode == 'VIEWPORT':
        # Check if we saved a proxy path
        if hasattr(context.scene, "vray_proxy_path") and context.scene.vray_proxy_path:
            saved_proxy_path = context.scene.vray_proxy_path

            if os.path.exists(saved_proxy_path):
                vray_collection = bpy.data.collections.get("vRay HDRI Controls")
                if vray_collection:
                    for obj in vray_collection.objects:
                        if obj.type == 'LIGHT' and "VRayDomeLight" in obj.name:
                            node_tree = obj.data.node_tree
                            bitmap_node = node_tree.nodes.get("V-Ray Bitmap")

                            if bitmap_node and hasattr(bitmap_node, 'BitmapBuffer'):
                                # Restore the saved proxy
                                print(f"V-Ray: Restoring proxy: {saved_proxy_path}")
                                bitmap_node.BitmapBuffer.file = saved_proxy_path

                                # Force updates
                                if hasattr(bitmap_node, 'update'):
                                    bitmap_node.update()
                                if hasattr(node_tree, 'update_tag'):
                                    node_tree.update_tag()

                                # Force viewport update
                                for area in context.screen.areas:
                                    if area.type == 'VIEW_3D':
                                        area.tag_redraw()

                                # Clear the saved path
                                context.scene.vray_proxy_path = ""
                                print("V-Ray: Render cancelled, restored proxy")
                                break

@bpy.app.handlers.persistent
def reset_proxy_after_render(dummy):
    """Handler to reset to proxy after render cancellation"""
    context = bpy.context
    settings = context.scene.hdri_settings

    # Debug output
    print("V-Ray: reset_proxy_after_render called")

    # Only swap back for 'VIEWPORT' proxy mode
    if settings.proxy_mode == 'VIEWPORT':
        vray_collection = bpy.data.collections.get("vRay HDRI Controls")
        if vray_collection:
            for obj in vray_collection.objects:
                if obj.type == 'LIGHT' and "VRayDomeLight" in obj.name:
                    node_tree = obj.data.node_tree
                    bitmap_node = node_tree.nodes.get("V-Ray Bitmap")

                    # Check if we stored a temporary proxy path
                    if bitmap_node and hasattr(bitmap_node, 'BitmapBuffer') and bitmap_node.BitmapBuffer:
                        if 'temp_proxy_path' in bitmap_node:
                            proxy_path = bitmap_node['temp_proxy_path']
                            if proxy_path and os.path.exists(proxy_path):
                                # Restore the proxy
                                bitmap_node.BitmapBuffer.file = proxy_path
                                print(f"V-Ray: Render cancelled, restored proxy: {proxy_path}")
                                del bitmap_node['temp_proxy_path']
                                return

                        # Fallback to creating a new proxy
                        current_file = bitmap_node.BitmapBuffer.file
                        if os.path.exists(current_file):
                            proxy_path = create_hdri_proxy(current_file, settings.proxy_resolution)
                            if proxy_path:
                                bitmap_node.BitmapBuffer.file = proxy_path
                                print(f"V-Ray: Render cancelled, created new proxy: {proxy_path}")
                    break


def register_vray_handlers():
    """Register V-Ray specific handlers"""
    if not hasattr(bpy.types.Scene, "vray_proxy_path"):
        bpy.types.Scene.vray_proxy_path = bpy.props.StringProperty()

    # Remove any existing handlers first to avoid duplicates
    unregister_vray_handlers()

    # Register the handlers
    bpy.app.handlers.render_init.append(reload_original_for_render)
    bpy.app.handlers.render_cancel.append(reset_proxy_after_render)
    bpy.app.handlers.render_complete.append(reset_proxy_after_render_complete)

    print("V-Ray: Render handlers registered")

def unregister_vray_handlers():
    """Unregister V-Ray specific handlers"""
    if reload_original_for_render in bpy.app.handlers.render_init:
        bpy.app.handlers.render_init.remove(reload_original_for_render)
    if reset_proxy_after_render in bpy.app.handlers.render_cancel:
        bpy.app.handlers.render_cancel.remove(reset_proxy_after_render)
    if reset_proxy_after_render_complete in bpy.app.handlers.render_complete:
        bpy.app.handlers.render_complete.remove(reset_proxy_after_render_complete)
    print("V-Ray: Handlers unregistered")
